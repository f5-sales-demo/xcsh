import json,time,os,hashlib
from pathlib import Path
os.environ["HF_HOME"]="/tmp/terraform-reranker-development-model-cache"
import torch
from sentence_transformers import CrossEncoder
torch.set_num_threads(4)
pin=json.loads(Path("/tmp/terraform-reranker-model-pin.json").read_text())
start=time.perf_counter()
model=CrossEncoder(pin["id"],revision=pin["sha"],device="cpu",max_length=256,trust_remote_code=False)
loaded=time.perf_counter()-start
report={"development_only":True,"qualification_passed":False,"model":pin,"load_seconds":loaded,"production_changed":False,"results":[]}
source=json.loads(Path("/tmp/terraform-reranker-candidates.json").read_text())
for suite in source["results"]:
 if "qualification" in suite["file"]:continue
 rows=[]
 for c in suite["results"]:
  begin=time.perf_counter();pairs=[[c["prompt"],r["text"]] for r in c["candidates"]]; scores=model.predict(pairs,batch_size=32,show_progress_bar=False) if pairs else []
  order=sorted(range(len(scores)),key=lambda i:(-float(scores[i]),c["candidates"][i]["uri"]))
  destinations=[c["candidates"][i]["uri"] for i in order[:5]]
  rows.append({"id":c["id"],"top1":bool(destinations and destinations[0] in c["expected"]),"top5":any(d in c["expected"] for d in destinations),"destinations":destinations,"rerank_ms":(time.perf_counter()-begin)*1000,"lexical_candidate_ms":c["ms"]})
  print(c["id"],rows[-1]["top1"],flush=True)
 summary={"file":suite["file"],"answerable":len(rows),"top1":sum(r["top1"] for r in rows),"top5":sum(r["top5"] for r in rows),"rerank_p95_ms":sorted(r["rerank_ms"] for r in rows)[int(len(rows)*.95)],"results":rows}
 report["results"].append(summary)
Path("/tmp/terraform-reranker-development-report.json").write_text(json.dumps(report,indent=2))
print(json.dumps({**report,"results":[{k:v for k,v in r.items() if k!="results"} for r in report["results"]]}),flush=True)
