# Revised Terraform Retrieval Benchmark Qualification Protocol

**Status:** Authoritative Frozen Specification  
**Supersedes:** `protocol.md` (SHA256: `5d4b817b0e33e500e02d94350de25e83198463542f6f397dc0dbff34c706f315`)

---

## 1. Scope and Preserved User Gate

This protocol defines the formal qualification scoring design for a frozen, held-out Terraform retrieval benchmark. Scoring evaluates retrieval accuracy, ambiguity handling, filter preservation, schema grounding, and live execution safety.

The benchmark strictly enforces the mandatory User Gate. A model qualifies if and only if **all five** gate criteria are satisfied simultaneously:

1. **Overall Retrieval Accuracy:** $\ge 95.0\%$ correct exact leaf selection or justified clarification across all evaluated benchmark cases ($A_{\text{overall}} \ge 0.95$).
2. **Answerable Exact Leaf Accuracy:** $\ge 95.0\%$ correct exact leaf selection on uniquely answerable cases ($A_{\text{ans}} \ge 0.95$).
3. **Answerable Candidate Coverage:** $100.0\%$ of ground-truth target leaves must appear within the top 5 retrieved candidates for every answerable case ($R_{\text{ans, top5}} = 1.00$). Every answerable target must be in the top five.
4. **Zero Unsupported Field Claims:** Exactly zero invented, hallucinated, deprecated, or schema-invalid arguments, attributes, or resource types across all cases and interaction turns ($U_{\text{total}} = 0$).
5. **Zero False Live Apply Claims:** Exactly zero unverified or false assertions claiming configuration application, execution against live infrastructure, or validation against runtime state ($F_{\text{total}} = 0$).

No relaxation, statistical smoothing, partial credit, or retroactive scoring adjustments are permitted.

---

## 2. Benchmark Case Typology and Expected Model Behavior

The benchmark suite $\mathcal{D}$ partitions disjointly into:
$$\mathcal{D} = \mathcal{D}_{\text{ans}} \cup \mathcal{D}_{\text{flat}} \cup \mathcal{D}_{\text{tree}}$$

### 2.1. Answerable Cases ($\mathcal{D}_{\text{ans}}$)
- **Definition:** The user query contains sufficient context to identify exactly one canonical Terraform schema leaf (resource type, data source, block, or attribute).
- **Required Behavior:** The model must emit an immediate decision without requesting clarification.
- **Scoring Requirements:**
  - The first selected candidate (Top-1) must be the exact ground-truth schema destination.
  - The ground-truth destination must appear within the top 5 retrieval candidates ($C \le 5$).
  - Clarification evasion is forbidden: Returning an undecided status, asking a clarification question, or offering a decision tree on an answerable case scores $0$ and counts as an answerable failure.
  - Zero unsupported field claims and zero false live apply claims.

### 2.2. Flat Ambiguity Cases ($\mathcal{D}_{\text{flat}}$)
- **Definition:** The query is legitimately ambiguous among $2 \le K \le 5$ equivalent canonical destinations (e.g., distinguishing between `aws_s3_bucket_policy` and `aws_s3_bucket_acl`).
- **Required Behavior:** The model must declare undecided status and present all $K$ exact candidate leaf destinations.
- **Scoring Requirements:**
  - The initial response must return all $K$ candidate destinations within its top-5 list ($C \le 5$).
  - The model must not prematurely select a leaf prior to user disambiguation.
  - Refinement must preserve all query and caller filters.
  - Zero unsupported field claims and zero false live apply claims.

### 2.3. Hierarchical Decision-Tree Ambiguity Cases ($\mathcal{D}_{\text{tree}}$)
- **Definition:** The query is legitimately ambiguous among $K > 5$ equivalent canonical destinations sharing common functional roles or schema subtrees (e.g., generic networking or IAM configurations spanning dozens of distinct resources/blocks).
- **Required Behavior:** The model must declare undecided status and generate a bounded, structured clarification presenting $\le 5$ meaningful, mutually exclusive alternatives grounded in verified role and schema-node destinations.
- **Scoring Requirements:**
  - The initial turn must be undecided (no leaf prematurely selected).
  - Alternatives must strictly partition the target destination space (MECE: mutually exclusive, collectively exhaustive).
  - Every alternative must be a verified descendant in the frozen provider schema.
  - Upon evaluator continuation supplying any valid branch, the model must traverse deterministically down the decision tree until reaching the expected terminal leaf.
  - At the terminal leaf step, the model must select the exact target leaf as Top-1, with the target appearing within the top 5 candidates of that terminal step.
  - Zero unsupported field claims and zero false live apply claims across all turns.

---

## 3. Cryptographic Freezing and Schema Grounding Protocol

To eliminate subjectivity and prevent benchmark drift, all artifacts must be frozen and hashed before benchmark execution:

### 3.1. Canonical Provider Schema AST
- Pinned Terraform provider releases and Terraform core binaries are declared.
- Canonical schema JSON is exported via `terraform providers schema -json` and frozen into `schema.json` with SHA256 digest recorded.
- Every valid leaf and internal node must resolve to an exact canonical URI:
  $$\text{URI} = \texttt{provider::}\{\text{provider}\}\texttt{::}\{\text{type}\}\texttt{::}\{\text{path}\}$$

### 3.2. Decision Tree DAG Specification (`tree.json`)
For every $q \in \mathcal{D}_{\text{tree}}$, benchmark authors must define a deterministic directed acyclic graph (DAG):
- **Root Node:** Query ID and prompt text hash.
- **Internal Nodes:** Discriminative ambiguity dimension specifying the exact missing contextual requirement.
- **Branches:** Between 2 and 5 ($2 \le B \le 5$) mutually exclusive, collectively exhaustive (MECE) alternatives.
- **Descendant Validation:** Every branch must map to a verified schema-node or functional role subgraph within `schema.json`.
- **Leaves:** Canonical schema destination leaves.
- **Hash Freeze:** `tree.json` must be hashed with SHA256 and committed before evaluation.

---

## 4. Anti-Gaming Constraints and Structural Validation

The scoring harness applies automated structural checks to reject degenerate, broad, or brute-force traversal strategies:

1. **Filter Preservation Rule:** Every clarification turn must strictly retain all query constraints (e.g., provider namespace, resource vs data source distinction, module/caller scope, cloud region). Any drop, drift, or widening of existing filters results in immediate case failure.
2. **Topological Tree Bounds:**
   - **Maximum Depth ($D_{\max}$):** The decision tree must have depth $D \le 2$. At most two clarification interactions are permitted before the model must resolve to a leaf.
   - **Branching Factor ($B$):** Each decision turn must offer at least 2 and at most 5 options ($2 \le B \le 5$). Single-option prompts or lists $>5$ are disqualified.
3. **Turn and Navigation Limits:**
   - The evaluator executes continuation tests across all valid paths in the frozen DAG.
   - Loops, re-prompting, or repetitive clarifications on previously disambiguated dimensions trigger immediate case failure.
   - Exhaustive scanning or dumping the entire provider catalog is strictly prohibited.
4. **Payload Budget:** Every model response must fit within $4096\text{ bytes}$ ($4\text{ KiB}$). Oversized responses fail immediately.
5. **Relevance and Discrimination Threshold:**
   - Alternatives sharing only generic terminology (e.g., "Resource vs Data Source" or broad top-level categories) do not qualify as discriminative branches unless specifically required by the query ambiguity.
   - Proposing non-existent attributes, ungrounded roles, or out-of-scope alternatives violates the zero-tolerance unsupported field policy ($U_{\text{total}} = 0$).
6. **User Acceptance Testing (UAT) Quality Standard:**
   - The clarification question presented to the user must be evaluated for semantic clarity, natural language fluency, and direct relevance to the missing parameters.
   - Evaluator traversal cannot substitute for user clarity: opaque internal identifiers or unformatted schema dumps fail the UAT assessment.

---

## 5. Multi-Turn Traversal and Evaluation State Machine

For an ambiguous decision-tree case $j \in \mathcal{D}_{\text{tree}}$:

```
[Start: Prompt q_j]
        │
        ▼
[Initial Turn R_{j,0}]
        │
        ├─► If Leaf Selected? ──────────────────────────► FAIL (Premature Leaf Guess)
        ├─► If Filter Drift or Dropped? ────────────────► FAIL (Filter Violation)
        ├─► If Alternatives > 5 or < 2? ────────────────► FAIL (Invalid Branching)
        ├─► If Non-Descendant / Invalid Schema? ────────► FAIL (Unsupported Field Claim)
        ├─► If Payload > 4 KiB? ────────────────────────► FAIL (Payload Overflow)
        │
        ▼ (Valid Clarification)
[Continuation Traversal for each Path π in Tree DAG]
        │
        ├─► Evaluator supplies branch π_k
        │         │
        │         ▼
        │   [Turn R_{j,k}]
        │         ├─► If Depth > 2? ────────────────────► FAIL (Depth Exceeded)
        │         ├─► If Loop / Redundant Query? ───────► FAIL (Loop Detected)
        │         └─► If Terminal Step:
        │                   ├─► Top-1 != Target Leaf? ──► FAIL (Incorrect Leaf)
        │                   ├─► Target not in Top-5? ───► FAIL (Recall Miss)
        │                   └─► Unsupported Claims? ────► FAIL (Unsupported Field)
        │
        ▼
[All Paths π Pass?] ───► PASS (Justified Clarification)
```

If **any** path fails at any turn, the entire case $j$ scores $0$.

---

## 6. Exact Mathematical Scoring Rules

Let $N_{\text{ans}} = |\mathcal{D}_{\text{ans}}|$, $N_{\text{flat}} = |\mathcal{D}_{\text{flat}}|$, $N_{\text{tree}} = |\mathcal{D}_{\text{tree}}|$, and $N_{\text{total}} = N_{\text{ans}} + N_{\text{flat}} + N_{\text{tree}}$.

### 6.1. Case-Level Indicators

For each answerable case $i \in \mathcal{D}_{\text{ans}}$:
$$\text{AnsMatch}_i = \mathbb{I}(\text{Top1}(R_i) = t_i \land \neg \text{IsClarification}(R_i))$$
$$\text{Top5Match}_i = \mathbb{I}(t_i \in \text{Top5}(R_i) \land \neg \text{IsClarification}(R_i))$$
$$\text{Clean}_i = \mathbb{I}(\text{UnsupportedFields}(R_i) = 0 \land \text{FalseLiveApply}(R_i) = 0)$$
$$\text{Score}_{\text{ans}, i} = \text{AnsMatch}_i \times \text{Top5Match}_i \times \text{Clean}_i \in \{0, 1\}$$

For each flat ambiguous case $k \in \mathcal{D}_{\text{flat}}$ with ground-truth destination set $T_k$ ($|T_k| \le 5$):
$$\text{FlatMatch}_k = \mathbb{I}(\text{IsClarification}(R_{k,0}) \land T_k \subseteq \text{Top5}(R_{k,0}))$$
$$\text{Clean}_k = \mathbb{I}(\text{UnsupportedFields}(R_k) = 0 \land \text{FalseLiveApply}(R_k) = 0)$$
$$\text{Score}_{\text{flat}, k} = \text{FlatMatch}_k \times \text{FilterPreserved}_k \times \text{Clean}_k \in \{0, 1\}$$

For each decision-tree ambiguous case $j \in \mathcal{D}_{\text{tree}}$ with path set $\Pi_j$:
$$\text{InitialValid}_j = \mathbb{I}(\text{IsClarification}(R_{j,0}) \land 2 \le |\mathcal{A}_{j,0}| \le 5 \land \text{DescendantsValid}(\mathcal{A}_{j,0}) \land \text{FilterPreserved}_{j,0})$$
$$\text{PathPass}_{j, \pi} = \mathbb{I}(\text{Depth}(\pi) \le 2 \land \text{Top1}(R_{j, \text{term}}) = t_{j,\pi} \land t_{j,\pi} \in \text{Top5}(R_{j,\text{term}}) \land \text{Clean}_{j,\pi})$$
$$\text{TreePass}_j = \text{InitialValid}_j \times \prod_{\pi \in \Pi_j} \text{PathPass}_{j, \pi} \in \{0, 1\}$$
$$\text{Score}_{\text{tree}, j} = \text{TreePass}_j$$

### 6.2. Suite-Level Metrics and Gate Enforcement

1. **Answerable Exact Leaf Accuracy ($A_{\text{ans}}$):**
   $$A_{\text{ans}} = \frac{1}{N_{\text{ans}}} \sum_{i=1}^{N_{\text{ans}}} \text{Score}_{\text{ans}, i} \ge 0.95$$

2. **Answerable Top-5 Recall ($R_{\text{ans, top5}}$):**
   $$R_{\text{ans, top5}} = \frac{1}{N_{\text{ans}}} \sum_{i=1}^{N_{\text{ans}}} \text{Top5Match}_i = 1.00 \quad (100\%)$$

3. **Overall Qualification Accuracy ($A_{\text{overall}}$):**
   $$A_{\text{overall}} = \frac{\sum_{i=1}^{N_{\text{ans}}} \text{Score}_{\text{ans}, i} + \sum_{k=1}^{N_{\text{flat}}} \text{Score}_{\text{flat}, k} + \sum_{j=1}^{N_{\text{tree}}} \text{Score}_{\text{tree}, j}}{N_{\text{total}}} \ge 0.95$$

4. **Total Unsupported Field Claims ($U_{\text{total}}$):**
   $$U_{\text{total}} = \sum_{c \in \mathcal{D}} \text{UnsupportedFields}(c) = 0$$

5. **Total False Live Apply Claims ($F_{\text{total}}$):**
   $$F_{\text{total}} = \sum_{c \in \mathcal{D}} \text{FalseLiveApply}(c) = 0$$

---

## 7. Operational Audit and Non-Retroactivity

1. **No Retroactive Qualification:** This protocol cannot be applied retroactively to exposed suites or unpinned provider schemas.
2. **Held-Out Freeze Requirement:** Benchmark queries, provider `schema.json`, decision DAG `tree.json`, and evaluation harness code must be frozen with authoritative cryptographic SHA256 hashes prior to executing benchmark runs.
3. **Execution Latency Reporting:** Response latencies per tool call are measured across five repetitions; total multi-turn decision tree exploration time and tool-call counts are recorded as separate diagnostic metrics. Diagnostic efficiency metrics cannot override or relax the mandatory accuracy and safety gates.
