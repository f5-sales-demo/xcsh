import json,hashlib,time,math
from pathlib import Path
import numpy as np,torch
from sentence_transformers import CrossEncoder
root=Path(__file__).parent
prep=json.loads((root/"preparation.json").read_text())
for f in prep["model_files"]: assert hashlib.sha256((root/"model"/f["path"]).read_bytes()).hexdigest()==f["sha256"]
corpus_raw=Path("/data/robin-GIT/worktrees/terraform-v1231-semantic-development/destinations.json").read_bytes();corpus=json.loads(corpus_raw)
assert hashlib.sha256(corpus_raw).hexdigest()=="fede0cccc094a8cd51935e84a2ad13003796074d812df0e1cc7d9743575ff58b"
by_uri={"xcsh://terraform-documentation/"+r["path"]+"#"+r["anchor"]:r for r in corpus["destinations"]}
torch.set_num_threads(4);model=CrossEncoder(str(root/"model"),local_files_only=True,device="cpu")
for name,source in [("original","/data/robin-GIT/worktrees/terraform-minilm-development/original-lexical.json"),("audited","/data/robin-GIT/worktrees/terraform-v1231-semantic-development/audited-lexical.json")]:
 lexical=json.loads(Path(source).read_text());results=[];all_times=[]
 for c in lexical["cases"]:
  uris=[u for u in dict.fromkeys(c["destinations"]) if u in by_uri][:20]
  texts=[r["description"]+" "+r["provider_type"]+" "+r["provider_name"].replace("_"," ")+" "+r["schema_path"].replace("."," ").replace("_"," ") for r in [by_uri[u] for u in uris]]
  pairs=[(c["prompt"],t) for t in texts];times=[];prior=None;dest=[]
  if pairs:
   for _ in range(5):
    start=time.perf_counter();scores=model.predict(pairs,batch_size=20);ranked=sorted(zip(uris,[round(float(x),12) for x in scores]),key=lambda x:(-x[1],x[0]));dest=[u for u,_ in ranked[:5]];times.append((time.perf_counter()-start)*1000)
    if prior is not None:assert ranked==prior
    prior=ranked
  all_times.extend(times);results.append({"id":c["id"],"kind":c["kind"],"destinations":dest,"top1":bool(dest and dest[0] in c["expected"]),"top5":any(u in c["expected"] for u in dest),"rerank_ms":times})
 answerable=[x for x in results if x["kind"]=="answerable"]
 report={"development_only":True,"qualification_passed":False,"production_imported":False,"corpus_sha256":hashlib.sha256(corpus_raw).hexdigest(),"suite_sha256":lexical["suite_sha256"],"model_revision":prep["model_revision"],"answerable":len(answerable),"top1":sum(x["top1"] for x in answerable),"top5":sum(x["top5"] for x in answerable),"rerank_p95_ms":sorted(all_times)[math.ceil(len(all_times)*.95)-1],"limitations":["Twenty precomputed lexical property candidates only; selection, rendering and lexical retrieval latency excluded.","Not independent qualification or installed runtime."],"results":results}
 (root/(name+".json")).write_text(json.dumps(report,indent=2)+"\n");print(json.dumps({k:v for k,v in report.items() if k!="results"}),flush=True)
