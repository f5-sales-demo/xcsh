import type {PropertyCandidate} from "./terraform-property-ranking";
import {propertyRequestedText,propertyTerms} from "./terraform-property-ranking";
export function referencedIdentityCandidates(query:string,rows:readonly PropertyCandidate[]):PropertyCandidate[]|undefined {
 const request=propertyRequestedText(query)?.split(/[!?;]|\.(?=\s|$)/)[0];
 if(!request)return undefined;
 const explicitReferent=/\b(?:referenced|referred[ -]to)\s+(?:(?:object|site|interface|resource|target)\s+)?(name|namespace|tenant|uid|kind)\b|\b(name|namespace|tenant|uid|kind)\s+of\s+(?:the\s+)?(?:referenced|referred[ -]to)\s+(?:object|site|interface|resource|target)\b/i.exec(request);
 if(!explicitReferent)return undefined;
 const before=request.slice(0,explicitReferent.index);
 if(/\b(?:not|no|never|without|either|or|example|such as)\b/i.test(before)||/["`‘“]/.test(before))return undefined;
 const identity=(explicitReferent[1]??explicitReferent[2])!.toLowerCase();
 const root=rows.find(r=>r.schema_path===identity);
 if(!root)return undefined;
 const referenceProse=(r:PropertyCandidate)=>/\b(?:referred object|referred object's|referenced object|referenced object's|reference target|referred to object)\b/i.test(r.description);
 if(referenceProse(root))return undefined;
 const reference=rows.filter(r=>r.provider_type===root.provider_type&&r.provider_name===root.provider_name&&r.schema_path.endsWith('.'+identity)&&referenceProse(r));
 if(!reference.length)return undefined;
 // The relation is field-local documented evidence; it does not establish the enclosing branch.
 return [root,...reference];
}
