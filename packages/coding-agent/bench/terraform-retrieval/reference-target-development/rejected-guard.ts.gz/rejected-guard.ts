export function requestsReferencedIdentity(query:string):boolean {
 const clauses=query.split(/[!?;]|\.(?=\s|$)/);
 return clauses.some(clause=>{
  if(/["'`‘’“”]|\b(?:not|no|never|without|either|or|example|such as|instead of|rather than)\b/i.test(clause))return false;
  return /\b(?:find|locate|where\s+(?:is|are)|which\s+(?:field|property|attribute))\b[^.!?;]*\b(?:referenced|referred[ -]to)\s+(?:(?:object|site|interface|resource|target)\s+)?(?:name|namespace|tenant|uid|kind)\b/i.test(clause);
 });
}
export function isRootIdentity(path:string):boolean {
 return !path.includes(".")&&["name","namespace","tenant","uid","kind"].includes(path);
}
