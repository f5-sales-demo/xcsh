# CPU Profile

| Duration | Samples | Interval | Functions |
|----------|---------|----------|----------|
| 731.2ms | 662 | 1.0ms | 160 |

**Top 10:** `(anonymous)` 32.9%, `all` 17.3%, `propertyTerms` 9.8%, `propertyTerms` 8.5%, `(anonymous)` 3.8%, `performIteration` 3.3%, `(module)` 2.6%, `Set` 1.6%, `includes` 0.9%, `filter` 0.8%

## Hot Functions (Self Time)

| Self% | Self | Total% | Total | Function | Location |
|------:|-----:|-------:|------:|----------|----------|
| 32.9% | 240.5ms | 51.7% | 378.4ms | `(anonymous)` | `/data/robin-GIT/worktrees/xcsh-4682-postmerge-qualification/packages/coding-agent/src/internal-urls/terraform-property-selection.ts:245` |
| 17.3% | 126.7ms | 17.3% | 126.7ms | `all` | `[native code]` |
| 9.8% | 72.1ms | 9.8% | 72.1ms | `propertyTerms` | `/data/robin-GIT/worktrees/xcsh-4682-postmerge-qualification/packages/coding-agent/src/internal-urls/terraform-property-selection.ts:70` |
| 8.5% | 62.4ms | 8.7% | 63.7ms | `propertyTerms` | `/data/robin-GIT/worktrees/xcsh-4682-postmerge-qualification/packages/coding-agent/src/internal-urls/terraform-property-selection.ts:65` |
| 3.8% | 28.0ms | 3.8% | 28.0ms | `(anonymous)` | `/data/robin-GIT/worktrees/xcsh-4682-postmerge-qualification/packages/coding-agent/src/internal-urls/terraform-property-selection.ts:250` |
| 3.3% | 24.1ms | 3.8% | 28.2ms | `performIteration` | `[native code]` |
| 2.6% | 19.4ms | 2.6% | 19.4ms | `(module)` | `/data/robin-GIT/worktrees/xcsh-4682-postmerge-qualification/packages/coding-agent/src/internal-urls/terraform-property-ranking.ts:17` |
| 1.6% | 11.9ms | 1.6% | 11.9ms | `Set` | `[native code]` |
| 0.9% | 6.9ms | 0.9% | 6.9ms | `includes` | `[native code]` |
| 0.8% | 6.2ms | 67.8% | 496.1ms | `filter` | `[native code]` |
| 0.8% | 5.9ms | 0.8% | 5.9ms | `parse` | `[native code]` |
| 0.7% | 5.4ms | 56.4% | 412.8ms | `some` | `[native code]` |
| 0.7% | 5.1ms | 60.6% | 443.1ms | `(anonymous)` | `/data/robin-GIT/worktrees/xcsh-4682-postmerge-qualification/packages/coding-agent/src/internal-urls/terraform-property-selection.ts:244` |
| 0.6% | 4.9ms | 0.6% | 4.9ms | `copyDataProperties` | `[native code]` |
| 0.5% | 4.3ms | 0.5% | 4.3ms | `propertyValueLookup` | `/data/robin-GIT/worktrees/xcsh-4682-postmerge-qualification/packages/coding-agent/src/internal-urls/terraform-property-ranking.ts:414` |
| 0.5% | 4.0ms | 11.5% | 84.1ms | `map` | `[native code]` |
| 0.4% | 3.3ms | 0.6% | 4.4ms | `match` | `[native code]` |
| 0.4% | 3.3ms | 0.5% | 4.3ms | `propertyRequestedText` | `/data/robin-GIT/worktrees/xcsh-4682-postmerge-qualification/packages/coding-agent/src/internal-urls/terraform-property-ranking.ts:552` |
| 0.4% | 3.2ms | 0.4% | 3.2ms | `(anonymous)` | `/data/robin-GIT/worktrees/xcsh-4682-postmerge-qualification/packages/coding-agent/src/internal-urls/terraform-property-ranking.ts` |
| 0.4% | 3.2ms | 0.4% | 3.2ms | `(anonymous)` | `/data/robin-GIT/worktrees/xcsh-4682-postmerge-qualification/packages/coding-agent/src/internal-urls/terraform-property-ranking.ts:66` |
| 0.4% | 3.2ms | 0.4% | 3.2ms | `(anonymous)` | `/data/robin-GIT/worktrees/xcsh-4682-postmerge-qualification/packages/coding-agent/src/internal-urls/terraform-property-ranking.ts:713` |
| 0.4% | 3.0ms | 0.5% | 4.0ms | `next` | `[native code]` |
| 0.3% | 2.8ms | 0.3% | 2.8ms | `(anonymous)` | `/data/robin-GIT/worktrees/xcsh-4682-postmerge-qualification/packages/coding-agent/src/internal-urls/terraform-property-selection.ts` |
| 0.3% | 2.3ms | 1.1% | 8.0ms | `(anonymous)` | `/data/robin-GIT/worktrees/xcsh-4682-postmerge-qualification/packages/coding-agent/src/internal-urls/terraform-property-ranking.ts:730` |
| 0.3% | 2.2ms | 0.3% | 2.2ms | `propertyRequestsBlock` | `/data/robin-GIT/worktrees/xcsh-4682-postmerge-qualification/packages/coding-agent/src/internal-urls/terraform-property-ranking.ts:384` |
| 0.3% | 2.2ms | 0.4% | 3.4ms | `(anonymous)` | `/data/robin-GIT/worktrees/xcsh-4682-postmerge-qualification/packages/coding-agent/src/internal-urls/terraform-property-ranking.ts:639` |
| 0.3% | 2.2ms | 0.3% | 2.2ms | `propertyRequestedText` | `/data/robin-GIT/worktrees/xcsh-4682-postmerge-qualification/packages/coding-agent/src/internal-urls/terraform-property-ranking.ts:486` |
| 0.3% | 2.1ms | 0.3% | 2.1ms | `(anonymous)` | `/data/robin-GIT/worktrees/xcsh-4682-postmerge-qualification/packages/coding-agent/src/internal-urls/terraform-property-ranking.ts:699` |
| 0.2% | 2.1ms | 0.2% | 2.1ms | `/\bused\s+to\b\|\bat\s+which\b\|\bwhen\s+(?:handling\|processing\|matching\|calling\|invoking\|executing)\b/i` | `[native code]` |
| 0.2% | 2.1ms | 0.5% | 4.3ms | `propertyTerms` | `/data/robin-GIT/worktrees/xcsh-4682-postmerge-qualification/packages/coding-agent/src/internal-urls/terraform-property-ranking.ts:60` |
| 0.2% | 2.0ms | 0.4% | 3.2ms | `propertyRequestedText` | `/data/robin-GIT/worktrees/xcsh-4682-postmerge-qualification/packages/coding-agent/src/internal-urls/terraform-property-ranking.ts:463` |
| 0.2% | 2.0ms | 0.2% | 2.0ms | `has` | `[native code]` |
| 0.2% | 2.0ms | 0.2% | 2.0ms | `(anonymous)` | `/data/robin-GIT/worktrees/xcsh-4682-postmerge-qualification/packages/coding-agent/src/internal-urls/terraform-property-index.ts:275` |
| 0.2% | 1.9ms | 0.3% | 2.7ms | `propertyTerms` | `/data/robin-GIT/worktrees/xcsh-4682-postmerge-qualification/packages/coding-agent/src/internal-urls/terraform-property-ranking.ts:57` |
| 0.1% | 1.2ms | 0.1% | 1.2ms | `prepare` | `[native code]` |
| 0.1% | 1.2ms | 0.1% | 1.2ms | `propertyRequestedText` | `/data/robin-GIT/worktrees/xcsh-4682-postmerge-qualification/packages/coding-agent/src/internal-urls/terraform-property-ranking.ts:550` |
| 0.1% | 1.2ms | 0.1% | 1.2ms | `/\b(?:example\|usage\|guidance)\b/i` | `[native code]` |
| 0.1% | 1.2ms | 0.1% | 1.2ms | `propertyRequestsBlock` | `/data/robin-GIT/worktrees/xcsh-4682-postmerge-qualification/packages/coding-agent/src/internal-urls/terraform-property-ranking.ts:363` |
| 0.1% | 1.2ms | 0.1% | 1.2ms | `interpretTerraformLifecycle` | `/data/robin-GIT/worktrees/xcsh-4682-postmerge-qualification/packages/coding-agent/src/internal-urls/terraform-lifecycle.ts` |
| 0.1% | 1.2ms | 0.1% | 1.2ms | `(anonymous)` | `/data/robin-GIT/worktrees/xcsh-4682-postmerge-qualification/packages/coding-agent/src/internal-urls/terraform-property-ranking.ts:656` |
| 0.1% | 1.2ms | 0.1% | 1.2ms | `selectPropertyDestinationInternal` | `/data/robin-GIT/worktrees/xcsh-4682-postmerge-qualification/packages/coding-agent/src/internal-urls/terraform-property-selection.ts` |
| 0.1% | 1.2ms | 0.1% | 1.2ms | `/\bto\s+(?:handle\|match\|configure\|enable\|provide)\b\|\bwhen\s+(?:declaring\|configuring\|reading)\b\|\bof\s+(?:an? \|the )?(?:existing \|managed )?(?:resource\|load balancer\|site\|object)\b/i` | `[native code]` |
| 0.1% | 1.2ms | 0.1% | 1.2ms | `rawContradicts` | `/data/robin-GIT/worktrees/xcsh-4682-postmerge-qualification/packages/coding-agent/src/internal-urls/terraform-property-selection.ts` |
| 0.1% | 1.2ms | 0.1% | 1.2ms | `/\bxcsh_[a-z0-9_]+\b\|\bto\s+(?:read\|fetch\|retrieve\|inspect\|look up\|lookup)\b/i` | `[native code]` |
| 0.1% | 1.2ms | 0.1% | 1.2ms | `propertyExcludedSchemaIdentifiers` | `/data/robin-GIT/worktrees/xcsh-4682-postmerge-qualification/packages/coding-agent/src/internal-urls/terraform-property-ranking.ts:306` |
| 0.1% | 1.2ms | 0.1% | 1.2ms | `get` | `[native code]` |
| 0.1% | 1.2ms | 0.3% | 2.4ms | `(anonymous)` | `/data/robin-GIT/worktrees/xcsh-4682-postmerge-qualification/packages/coding-agent/src/internal-urls/terraform-property-selection.ts:397` |
| 0.1% | 1.2ms | 0.1% | 1.2ms | `propertyMatchesWorkloadArchitecture` | `/data/robin-GIT/worktrees/xcsh-4682-postmerge-qualification/packages/coding-agent/src/internal-urls/terraform-property-ranking.ts:138` |
| 0.1% | 1.2ms | 0.1% | 1.2ms | `join` | `[native code]` |
| 0.1% | 1.1ms | 0.1% | 1.1ms | `(anonymous)` | `/data/robin-GIT/worktrees/xcsh-4682-postmerge-qualification/packages/coding-agent/src/internal-urls/terraform-property-ranking.ts:745` |
| 0.1% | 1.1ms | 0.8% | 6.4ms | `propertyTerms` | `/data/robin-GIT/worktrees/xcsh-4682-postmerge-qualification/packages/coding-agent/src/internal-urls/terraform-property-ranking.ts:64` |
| 0.1% | 1.1ms | 0.1% | 1.1ms | `(anonymous)` | `/data/robin-GIT/worktrees/xcsh-4682-postmerge-qualification/packages/coding-agent/src/internal-urls/terraform-property-ranking.ts:733` |
| 0.1% | 1.1ms | 0.2% | 2.1ms | `propertyValueLookup` | `/data/robin-GIT/worktrees/xcsh-4682-postmerge-qualification/packages/coding-agent/src/internal-urls/terraform-property-ranking.ts:409` |
| 0.1% | 1.1ms | 0.1% | 1.1ms | `propertyTerms` | `/data/robin-GIT/worktrees/xcsh-4682-postmerge-qualification/packages/coding-agent/src/internal-urls/terraform-property-ranking.ts:70` |
| 0.1% | 1.1ms | 0.4% | 3.2ms | `sort` | `[native code]` |
| 0.1% | 1.1ms | 0.1% | 1.1ms | `weight` | `/data/robin-GIT/worktrees/xcsh-4682-postmerge-qualification/packages/coding-agent/src/internal-urls/terraform-property-ranking.ts:625` |
| 0.1% | 1.1ms | 0.2% | 2.0ms | `(anonymous)` | `/data/robin-GIT/worktrees/xcsh-4682-postmerge-qualification/packages/coding-agent/src/internal-urls/terraform-property-index.ts:310` |
| 0.1% | 1.0ms | 0.1% | 1.0ms | `/\b(?:field\|attribute\|property\|parameter\|argument)\b\s+filters?\s+.+?\s+by\s+(.+)/i` | `[native code]` |
| 0.1% | 1.0ms | 0.2% | 2.1ms | `(anonymous)` | `/data/robin-GIT/worktrees/xcsh-4682-postmerge-qualification/packages/coding-agent/src/internal-urls/terraform-property-ranking.ts:655` |
| 0.1% | 1.0ms | 0.1% | 1.0ms | `toFixed` | `[native code]` |
| 0.1% | 1.0ms | 0.1% | 1.0ms | `/\bfor\b(?!\s+[a-z]*(?:tion\|sion\|ing)\b)\|\breferenced in\b\|\bto\s+(?:handle\|match\|configure\|enable\|provide)\b\|\bwhen\s+(?:declaring\|configuring\|reading)\b\|\bof\s+(?:an? \|the )?(?:existing \|managed )?(?:resource\|load balancer\|site\|object)\b/i` | `[native code]` |
| 0.1% | 1.0ms | 0.1% | 1.0ms | `propertyRequestedText` | `/data/robin-GIT/worktrees/xcsh-4682-postmerge-qualification/packages/coding-agent/src/internal-urls/terraform-property-ranking.ts:511` |
| 0.1% | 1.0ms | 0.1% | 1.0ms | ``/\b(under\|within\|inside\|schema path\|branch\|path\|or\|and\|locate\|find\|point me to\|where is\|where are\|where do i put\|where do\|where does\|i need)\s+(?:(?:the\|its)\s+)?(`?)([a-z][a-z0-9_.-]*\.[a-z0-9_.-]+)\2/g`` | `[native code]` |
| 0.1% | 1.0ms | 0.1% | 1.0ms | `propertyRequestedText` | `/data/robin-GIT/worktrees/xcsh-4682-postmerge-qualification/packages/coding-agent/src/internal-urls/terraform-property-ranking.ts` |
| 0.1% | 1.0ms | 0.1% | 1.0ms | `propertyValueLookup` | `/data/robin-GIT/worktrees/xcsh-4682-postmerge-qualification/packages/coding-agent/src/internal-urls/terraform-property-ranking.ts:404` |
| 0.1% | 1.0ms | 3.2% | 23.6ms | `(anonymous)` | `/data/robin-GIT/worktrees/xcsh-4682-postmerge-qualification/packages/coding-agent/src/internal-urls/terraform-property-ranking.ts:680` |
| 0.1% | 1.0ms | 0.5% | 3.9ms | `searchPropertyIndex` | `/data/robin-GIT/worktrees/xcsh-4682-postmerge-qualification/packages/coding-agent/src/internal-urls/terraform-property-index.ts:274` |
| 0.1% | 1.0ms | 3.6% | 26.8ms | `propertyNamesCollection` | `/data/robin-GIT/worktrees/xcsh-4682-postmerge-qualification/packages/coding-agent/src/internal-urls/terraform-property-ranking.ts:564` |
| 0.1% | 994us | 0.1% | 994us | `propertyRequestsBlock` | `/data/robin-GIT/worktrees/xcsh-4682-postmerge-qualification/packages/coding-agent/src/internal-urls/terraform-property-ranking.ts:376` |
| 0.1% | 983us | 0.1% | 983us | `propertyTerms` | `/data/robin-GIT/worktrees/xcsh-4682-postmerge-qualification/packages/coding-agent/src/internal-urls/terraform-property-selection.ts` |
| 0.1% | 975us | 0.1% | 975us | `/regular expressions?/g` | `[native code]` |
| 0.1% | 973us | 0.1% | 973us | `(anonymous)` | `/data/robin-GIT/worktrees/xcsh-4682-postmerge-qualification/packages/coding-agent/src/internal-urls/terraform-property-ranking.ts:631` |
| 0.1% | 973us | 0.1% | 973us | `propertyRequestedText` | `/data/robin-GIT/worktrees/xcsh-4682-postmerge-qualification/packages/coding-agent/src/internal-urls/terraform-property-ranking.ts:535` |
| 0.1% | 968us | 0.1% | 968us | `/\b(?:specify\|set\|provide\|supply)\b\s+(?!(?:(?:an?\|the)\s+)?(?:xcsh_\|resource\b\|data[ -]source\b\|provider\b))(.+)/i` | `[native code]` |
| 0.1% | 954us | 0.1% | 954us | `(anonymous)` | `/data/robin-GIT/worktrees/xcsh-4682-postmerge-qualification/packages/coding-agent/src/internal-urls/terraform-property-ranking.ts:726` |
| 0.1% | 950us | 0.1% | 950us | `exec` | `[native code]` |
| 0.1% | 942us | 0.1% | 942us | `propertyRequestedText` | `/data/robin-GIT/worktrees/xcsh-4682-postmerge-qualification/packages/coding-agent/src/internal-urls/terraform-property-ranking.ts:555` |
| 0.1% | 942us | 0.7% | 5.4ms | `propertyRequestedText` | `/data/robin-GIT/worktrees/xcsh-4682-postmerge-qualification/packages/coding-agent/src/internal-urls/terraform-property-ranking.ts:454` |
| 0.1% | 937us | 0.1% | 937us | `(anonymous)` | `/data/robin-GIT/worktrees/xcsh-4682-postmerge-qualification/packages/coding-agent/src/internal-urls/terraform-property-index.ts:323` |
| 0.1% | 926us | 0.1% | 926us | `propertyConflictingNamedScope` | `/data/robin-GIT/worktrees/xcsh-4682-postmerge-qualification/packages/coding-agent/src/internal-urls/terraform-property-ranking.ts:325` |
| 0.1% | 923us | 0.1% | 923us | `propertyTerms` | `/data/robin-GIT/worktrees/xcsh-4682-postmerge-qualification/packages/coding-agent/src/internal-urls/terraform-property-ranking.ts:53` |
| 0.1% | 922us | 0.1% | 922us | `flatIntoArray` | `[native code]` |
| 0.1% | 911us | 0.1% | 911us | `propertyQueryTerms` | `/data/robin-GIT/worktrees/xcsh-4682-postmerge-qualification/packages/coding-agent/src/internal-urls/terraform-property-ranking.ts` |
| 0.1% | 894us | 0.3% | 2.8ms | `(anonymous)` | `/data/robin-GIT/worktrees/xcsh-4682-postmerge-qualification/packages/coding-agent/src/internal-urls/terraform-property-ranking.ts:649` |
| 0.1% | 885us | 0.4% | 3.0ms | `propertyRequestedText` | `/data/robin-GIT/worktrees/xcsh-4682-postmerge-qualification/packages/coding-agent/src/internal-urls/terraform-property-ranking.ts:551` |
| 0.1% | 876us | 0.1% | 876us | `replace` | `[native code]` |

## Call Tree (Total Time)

| Total% | Total | Self% | Self | Function | Location |
|-------:|------:|------:|-----:|----------|----------|
| 97.3% | 711.5ms | 0.0% | 0us | `(module)` | `/tmp/terraform-expanded-profile.ts:1` |
| 67.9% | 496.5ms | 0.0% | 0us | `selectPropertyDestination` | `/data/robin-GIT/worktrees/xcsh-4682-postmerge-qualification/packages/coding-agent/src/internal-urls/terraform-property-selection.ts:648` |
| 67.8% | 496.1ms | 0.8% | 6.2ms | `filter` | `[native code]` |
| 62.1% | 454.1ms | 0.0% | 0us | `selectPropertyDestinationInternal` | `/data/robin-GIT/worktrees/xcsh-4682-postmerge-qualification/packages/coding-agent/src/internal-urls/terraform-property-selection.ts:236` |
| 60.6% | 443.1ms | 0.7% | 5.1ms | `(anonymous)` | `/data/robin-GIT/worktrees/xcsh-4682-postmerge-qualification/packages/coding-agent/src/internal-urls/terraform-property-selection.ts:244` |
| 56.4% | 412.8ms | 0.7% | 5.4ms | `some` | `[native code]` |
| 51.7% | 378.4ms | 32.9% | 240.5ms | `(anonymous)` | `/data/robin-GIT/worktrees/xcsh-4682-postmerge-qualification/packages/coding-agent/src/internal-urls/terraform-property-selection.ts:245` |
| 17.3% | 126.7ms | 17.3% | 126.7ms | `all` | `[native code]` |
| 14.8% | 108.3ms | 0.0% | 0us | `searchPropertyIndex` | `/data/robin-GIT/worktrees/xcsh-4682-postmerge-qualification/packages/coding-agent/src/internal-urls/terraform-property-index.ts:253` |
| 11.5% | 84.1ms | 0.5% | 4.0ms | `map` | `[native code]` |
| 9.8% | 72.1ms | 9.8% | 72.1ms | `propertyTerms` | `/data/robin-GIT/worktrees/xcsh-4682-postmerge-qualification/packages/coding-agent/src/internal-urls/terraform-property-selection.ts:70` |
| 9.0% | 66.3ms | 0.0% | 0us | `searchPropertyIndex` | `/data/robin-GIT/worktrees/xcsh-4682-postmerge-qualification/packages/coding-agent/src/internal-urls/terraform-property-index.ts:317` |
| 8.7% | 63.9ms | 0.0% | 0us | `rankPropertyScope` | `/data/robin-GIT/worktrees/xcsh-4682-postmerge-qualification/packages/coding-agent/src/internal-urls/terraform-property-ranking.ts:624` |
| 8.7% | 63.7ms | 8.5% | 62.4ms | `propertyTerms` | `/data/robin-GIT/worktrees/xcsh-4682-postmerge-qualification/packages/coding-agent/src/internal-urls/terraform-property-selection.ts:65` |
| 3.8% | 28.2ms | 3.3% | 24.1ms | `performIteration` | `[native code]` |
| 3.8% | 28.0ms | 3.8% | 28.0ms | `(anonymous)` | `/data/robin-GIT/worktrees/xcsh-4682-postmerge-qualification/packages/coding-agent/src/internal-urls/terraform-property-selection.ts:250` |
| 3.6% | 26.8ms | 0.1% | 1.0ms | `propertyNamesCollection` | `/data/robin-GIT/worktrees/xcsh-4682-postmerge-qualification/packages/coding-agent/src/internal-urls/terraform-property-ranking.ts:564` |
| 3.5% | 25.8ms | 0.0% | 0us | `propertyRequestsCollection` | `/data/robin-GIT/worktrees/xcsh-4682-postmerge-qualification/packages/coding-agent/src/internal-urls/terraform-property-ranking.ts:559` |
| 3.2% | 23.6ms | 0.1% | 1.0ms | `(anonymous)` | `/data/robin-GIT/worktrees/xcsh-4682-postmerge-qualification/packages/coding-agent/src/internal-urls/terraform-property-ranking.ts:680` |
| 3.1% | 22.7ms | 0.0% | 0us | `selectPropertyDestinationInternal` | `/data/robin-GIT/worktrees/xcsh-4682-postmerge-qualification/packages/coding-agent/src/internal-urls/terraform-property-selection.ts:235` |
| 2.8% | 20.7ms | 0.0% | 0us | `(anonymous)` | `/data/robin-GIT/worktrees/xcsh-4682-postmerge-qualification/packages/coding-agent/src/internal-urls/terraform-property-selection.ts:235` |
| 2.6% | 19.5ms | 0.0% | 0us | `rawContradicts` | `/data/robin-GIT/worktrees/xcsh-4682-postmerge-qualification/packages/coding-agent/src/internal-urls/terraform-property-selection.ts:41` |
| 2.6% | 19.4ms | 2.6% | 19.4ms | `(module)` | `/data/robin-GIT/worktrees/xcsh-4682-postmerge-qualification/packages/coding-agent/src/internal-urls/terraform-property-ranking.ts:17` |
| 2.4% | 18.1ms | 0.0% | 0us | `propertyTerms` | `/data/robin-GIT/worktrees/xcsh-4682-postmerge-qualification/packages/coding-agent/src/internal-urls/terraform-property-selection.ts:67` |
| 1.7% | 12.8ms | 0.0% | 0us | `searchPropertyIndex` | `/data/robin-GIT/worktrees/xcsh-4682-postmerge-qualification/packages/coding-agent/src/internal-urls/terraform-property-index.ts:294` |
| 1.6% | 11.9ms | 1.6% | 11.9ms | `Set` | `[native code]` |
| 1.4% | 10.8ms | 0.0% | 0us | `searchPropertyIndex` | `/data/robin-GIT/worktrees/xcsh-4682-postmerge-qualification/packages/coding-agent/src/internal-urls/terraform-property-index.ts:302` |
| 1.2% | 8.7ms | 0.0% | 0us | `propertyRequestedText` | `/data/robin-GIT/worktrees/xcsh-4682-postmerge-qualification/packages/coding-agent/src/internal-urls/terraform-property-ranking.ts:533` |
| 1.1% | 8.0ms | 0.3% | 2.3ms | `(anonymous)` | `/data/robin-GIT/worktrees/xcsh-4682-postmerge-qualification/packages/coding-agent/src/internal-urls/terraform-property-ranking.ts:730` |
| 0.9% | 6.9ms | 0.9% | 6.9ms | `includes` | `[native code]` |
| 0.9% | 6.7ms | 0.0% | 0us | `(anonymous)` | `/data/robin-GIT/worktrees/xcsh-4682-postmerge-qualification/packages/coding-agent/src/internal-urls/terraform-property-selection.ts:242` |
| 0.8% | 6.4ms | 0.1% | 1.1ms | `propertyTerms` | `/data/robin-GIT/worktrees/xcsh-4682-postmerge-qualification/packages/coding-agent/src/internal-urls/terraform-property-ranking.ts:64` |
| 0.8% | 6.3ms | 0.0% | 0us | `(anonymous)` | `/data/robin-GIT/worktrees/xcsh-4682-postmerge-qualification/packages/coding-agent/src/internal-urls/terraform-property-ranking.ts:626` |
| 0.8% | 5.9ms | 0.8% | 5.9ms | `parse` | `[native code]` |
| 0.7% | 5.4ms | 0.1% | 942us | `propertyRequestedText` | `/data/robin-GIT/worktrees/xcsh-4682-postmerge-qualification/packages/coding-agent/src/internal-urls/terraform-property-ranking.ts:454` |
| 0.6% | 4.9ms | 0.6% | 4.9ms | `copyDataProperties` | `[native code]` |
| 0.6% | 4.4ms | 0.4% | 3.3ms | `match` | `[native code]` |
| 0.5% | 4.3ms | 0.4% | 3.3ms | `propertyRequestedText` | `/data/robin-GIT/worktrees/xcsh-4682-postmerge-qualification/packages/coding-agent/src/internal-urls/terraform-property-ranking.ts:552` |
| 0.5% | 4.3ms | 0.0% | 0us | `searchPropertyIndex` | `/data/robin-GIT/worktrees/xcsh-4682-postmerge-qualification/packages/coding-agent/src/internal-urls/terraform-property-index.ts:270` |
| 0.5% | 4.3ms | 0.5% | 4.3ms | `propertyValueLookup` | `/data/robin-GIT/worktrees/xcsh-4682-postmerge-qualification/packages/coding-agent/src/internal-urls/terraform-property-ranking.ts:414` |
| 0.5% | 4.3ms | 0.2% | 2.1ms | `propertyTerms` | `/data/robin-GIT/worktrees/xcsh-4682-postmerge-qualification/packages/coding-agent/src/internal-urls/terraform-property-ranking.ts:60` |
| 0.5% | 4.2ms | 0.0% | 0us | `(anonymous)` | `/data/robin-GIT/worktrees/xcsh-4682-postmerge-qualification/packages/coding-agent/src/internal-urls/terraform-property-selection.ts:240` |
| 0.5% | 4.0ms | 0.4% | 3.0ms | `next` | `[native code]` |
| 0.5% | 3.9ms | 0.1% | 1.0ms | `searchPropertyIndex` | `/data/robin-GIT/worktrees/xcsh-4682-postmerge-qualification/packages/coding-agent/src/internal-urls/terraform-property-index.ts:274` |
| 0.4% | 3.4ms | 0.3% | 2.2ms | `(anonymous)` | `/data/robin-GIT/worktrees/xcsh-4682-postmerge-qualification/packages/coding-agent/src/internal-urls/terraform-property-ranking.ts:639` |
| 0.4% | 3.3ms | 0.0% | 0us | `(anonymous)` | `/data/robin-GIT/worktrees/xcsh-4682-postmerge-qualification/packages/coding-agent/src/internal-urls/terraform-property-selection.ts:101` |
| 0.4% | 3.3ms | 0.0% | 0us | `selectPropertyDestinationInternal` | `/data/robin-GIT/worktrees/xcsh-4682-postmerge-qualification/packages/coding-agent/src/internal-urls/terraform-property-selection.ts:101` |
| 0.4% | 3.3ms | 0.0% | 0us | `propertyExplicitSchemaPaths` | `/data/robin-GIT/worktrees/xcsh-4682-postmerge-qualification/packages/coding-agent/src/internal-urls/terraform-property-ranking.ts:279` |
| 0.4% | 3.3ms | 0.0% | 0us | `propertyMatchesExplicitPaths` | `/data/robin-GIT/worktrees/xcsh-4682-postmerge-qualification/packages/coding-agent/src/internal-urls/terraform-property-ranking.ts:285` |
| 0.4% | 3.2ms | 0.1% | 1.1ms | `sort` | `[native code]` |
| 0.4% | 3.2ms | 0.4% | 3.2ms | `(anonymous)` | `/data/robin-GIT/worktrees/xcsh-4682-postmerge-qualification/packages/coding-agent/src/internal-urls/terraform-property-ranking.ts` |
| 0.4% | 3.2ms | 0.4% | 3.2ms | `(anonymous)` | `/data/robin-GIT/worktrees/xcsh-4682-postmerge-qualification/packages/coding-agent/src/internal-urls/terraform-property-ranking.ts:66` |
| 0.4% | 3.2ms | 0.2% | 2.0ms | `propertyRequestedText` | `/data/robin-GIT/worktrees/xcsh-4682-postmerge-qualification/packages/coding-agent/src/internal-urls/terraform-property-ranking.ts:463` |
| 0.4% | 3.2ms | 0.4% | 3.2ms | `(anonymous)` | `/data/robin-GIT/worktrees/xcsh-4682-postmerge-qualification/packages/coding-agent/src/internal-urls/terraform-property-ranking.ts:713` |
| 0.4% | 3.0ms | 0.1% | 885us | `propertyRequestedText` | `/data/robin-GIT/worktrees/xcsh-4682-postmerge-qualification/packages/coding-agent/src/internal-urls/terraform-property-ranking.ts:551` |
| 0.3% | 2.8ms | 0.1% | 894us | `(anonymous)` | `/data/robin-GIT/worktrees/xcsh-4682-postmerge-qualification/packages/coding-agent/src/internal-urls/terraform-property-ranking.ts:649` |
| 0.3% | 2.8ms | 0.3% | 2.8ms | `(anonymous)` | `/data/robin-GIT/worktrees/xcsh-4682-postmerge-qualification/packages/coding-agent/src/internal-urls/terraform-property-selection.ts` |
| 0.3% | 2.7ms | 0.2% | 1.9ms | `propertyTerms` | `/data/robin-GIT/worktrees/xcsh-4682-postmerge-qualification/packages/coding-agent/src/internal-urls/terraform-property-ranking.ts:57` |
| 0.3% | 2.4ms | 0.0% | 0us | `(anonymous)` | `/data/robin-GIT/worktrees/xcsh-4682-postmerge-qualification/packages/coding-agent/src/internal-urls/terraform-property-ranking.ts:732` |
| 0.3% | 2.4ms | 0.1% | 1.2ms | `(anonymous)` | `/data/robin-GIT/worktrees/xcsh-4682-postmerge-qualification/packages/coding-agent/src/internal-urls/terraform-property-selection.ts:397` |
| 0.3% | 2.4ms | 0.0% | 0us | `selectPropertyDestinationInternal` | `/data/robin-GIT/worktrees/xcsh-4682-postmerge-qualification/packages/coding-agent/src/internal-urls/terraform-property-selection.ts:394` |
| 0.3% | 2.2ms | 0.3% | 2.2ms | `propertyRequestsBlock` | `/data/robin-GIT/worktrees/xcsh-4682-postmerge-qualification/packages/coding-agent/src/internal-urls/terraform-property-ranking.ts:384` |
| 0.3% | 2.2ms | 0.3% | 2.2ms | `propertyRequestedText` | `/data/robin-GIT/worktrees/xcsh-4682-postmerge-qualification/packages/coding-agent/src/internal-urls/terraform-property-ranking.ts:486` |
| 0.3% | 2.2ms | 0.0% | 0us | `schemaPathMentions` | `/data/robin-GIT/worktrees/xcsh-4682-postmerge-qualification/packages/coding-agent/src/internal-urls/terraform-property-ranking.ts:255` |
| 0.3% | 2.2ms | 0.0% | 0us | `(anonymous)` | `/data/robin-GIT/worktrees/xcsh-4682-postmerge-qualification/packages/coding-agent/src/internal-urls/terraform-property-ranking.ts:636` |
| 0.3% | 2.1ms | 0.3% | 2.1ms | `(anonymous)` | `/data/robin-GIT/worktrees/xcsh-4682-postmerge-qualification/packages/coding-agent/src/internal-urls/terraform-property-ranking.ts:699` |
| 0.2% | 2.1ms | 0.1% | 1.0ms | `(anonymous)` | `/data/robin-GIT/worktrees/xcsh-4682-postmerge-qualification/packages/coding-agent/src/internal-urls/terraform-property-ranking.ts:655` |
| 0.2% | 2.1ms | 0.2% | 2.1ms | `/\bused\s+to\b\|\bat\s+which\b\|\bwhen\s+(?:handling\|processing\|matching\|calling\|invoking\|executing)\b/i` | `[native code]` |
| 0.2% | 2.1ms | 0.1% | 1.1ms | `propertyValueLookup` | `/data/robin-GIT/worktrees/xcsh-4682-postmerge-qualification/packages/coding-agent/src/internal-urls/terraform-property-ranking.ts:409` |
| 0.2% | 2.0ms | 0.0% | 0us | `(anonymous)` | `/data/robin-GIT/worktrees/xcsh-4682-postmerge-qualification/packages/coding-agent/src/internal-urls/terraform-property-index.ts:307` |
| 0.2% | 2.0ms | 0.0% | 0us | `selectPropertyDestinationInternal` | `/data/robin-GIT/worktrees/xcsh-4682-postmerge-qualification/packages/coding-agent/src/internal-urls/terraform-property-selection.ts:232` |
| 0.2% | 2.0ms | 0.2% | 2.0ms | `has` | `[native code]` |
| 0.2% | 2.0ms | 0.2% | 2.0ms | `(anonymous)` | `/data/robin-GIT/worktrees/xcsh-4682-postmerge-qualification/packages/coding-agent/src/internal-urls/terraform-property-index.ts:275` |
| 0.2% | 2.0ms | 0.1% | 1.1ms | `(anonymous)` | `/data/robin-GIT/worktrees/xcsh-4682-postmerge-qualification/packages/coding-agent/src/internal-urls/terraform-property-index.ts:310` |
| 0.2% | 2.0ms | 0.0% | 0us | `searchPropertyIndex` | `/data/robin-GIT/worktrees/xcsh-4682-postmerge-qualification/packages/coding-agent/src/internal-urls/terraform-property-index.ts:211` |
| 0.2% | 2.0ms | 0.0% | 0us | `propertyRequestedType` | `/data/robin-GIT/worktrees/xcsh-4682-postmerge-qualification/packages/coding-agent/src/internal-urls/terraform-property-ranking.ts:223` |
| 0.2% | 1.9ms | 0.0% | 0us | `(anonymous)` | `/data/robin-GIT/worktrees/xcsh-4682-postmerge-qualification/packages/coding-agent/src/internal-urls/terraform-property-index.ts:308` |
| 0.1% | 1.2ms | 0.1% | 1.2ms | `prepare` | `[native code]` |
| 0.1% | 1.2ms | 0.0% | 0us | `[prepareOwned]` | `bun:sqlite:330` |
| 0.1% | 1.2ms | 0.0% | 0us | `query` | `bun:sqlite:347` |
| 0.1% | 1.2ms | 0.0% | 0us | `searchPropertyIndex` | `/data/robin-GIT/worktrees/xcsh-4682-postmerge-qualification/packages/coding-agent/src/internal-urls/terraform-property-index.ts:250` |
| 0.1% | 1.2ms | 0.0% | 0us | `(anonymous)` | `/data/robin-GIT/worktrees/xcsh-4682-postmerge-qualification/packages/coding-agent/src/internal-urls/terraform-property-index.ts:306` |
| 0.1% | 1.2ms | 0.1% | 1.2ms | `propertyRequestedText` | `/data/robin-GIT/worktrees/xcsh-4682-postmerge-qualification/packages/coding-agent/src/internal-urls/terraform-property-ranking.ts:550` |
| 0.1% | 1.2ms | 0.1% | 1.2ms | `/\b(?:example\|usage\|guidance)\b/i` | `[native code]` |
| 0.1% | 1.2ms | 0.0% | 0us | `propertyValueLookup` | `/data/robin-GIT/worktrees/xcsh-4682-postmerge-qualification/packages/coding-agent/src/internal-urls/terraform-property-ranking.ts:413` |
| 0.1% | 1.2ms | 0.1% | 1.2ms | `propertyRequestsBlock` | `/data/robin-GIT/worktrees/xcsh-4682-postmerge-qualification/packages/coding-agent/src/internal-urls/terraform-property-ranking.ts:363` |
| 0.1% | 1.2ms | 0.1% | 1.2ms | `interpretTerraformLifecycle` | `/data/robin-GIT/worktrees/xcsh-4682-postmerge-qualification/packages/coding-agent/src/internal-urls/terraform-lifecycle.ts` |
| 0.1% | 1.2ms | 0.0% | 0us | `selectPropertyDestinationInternal` | `/data/robin-GIT/worktrees/xcsh-4682-postmerge-qualification/packages/coding-agent/src/internal-urls/terraform-property-selection.ts:194` |
| 0.1% | 1.2ms | 0.1% | 1.2ms | `(anonymous)` | `/data/robin-GIT/worktrees/xcsh-4682-postmerge-qualification/packages/coding-agent/src/internal-urls/terraform-property-ranking.ts:656` |
| 0.1% | 1.2ms | 0.1% | 1.2ms | `selectPropertyDestinationInternal` | `/data/robin-GIT/worktrees/xcsh-4682-postmerge-qualification/packages/coding-agent/src/internal-urls/terraform-property-selection.ts` |
| 0.1% | 1.2ms | 0.0% | 0us | `searchPropertyIndex` | `/data/robin-GIT/worktrees/xcsh-4682-postmerge-qualification/packages/coding-agent/src/internal-urls/terraform-property-index.ts:301` |
| 0.1% | 1.2ms | 0.1% | 1.2ms | `/\bto\s+(?:handle\|match\|configure\|enable\|provide)\b\|\bwhen\s+(?:declaring\|configuring\|reading)\b\|\bof\s+(?:an? \|the )?(?:existing \|managed )?(?:resource\|load balancer\|site\|object)\b/i` | `[native code]` |
| 0.1% | 1.2ms | 0.1% | 1.2ms | `rawContradicts` | `/data/robin-GIT/worktrees/xcsh-4682-postmerge-qualification/packages/coding-agent/src/internal-urls/terraform-property-selection.ts` |
| 0.1% | 1.2ms | 0.0% | 0us | `propertyRequestedText` | `/data/robin-GIT/worktrees/xcsh-4682-postmerge-qualification/packages/coding-agent/src/internal-urls/terraform-property-ranking.ts:514` |
| 0.1% | 1.2ms | 0.1% | 1.2ms | `/\bxcsh_[a-z0-9_]+\b\|\bto\s+(?:read\|fetch\|retrieve\|inspect\|look up\|lookup)\b/i` | `[native code]` |
| 0.1% | 1.2ms | 0.0% | 0us | `selectPropertyDestinationInternal` | `/data/robin-GIT/worktrees/xcsh-4682-postmerge-qualification/packages/coding-agent/src/internal-urls/terraform-property-selection.ts:83` |
| 0.1% | 1.2ms | 0.1% | 1.2ms | `propertyExcludedSchemaIdentifiers` | `/data/robin-GIT/worktrees/xcsh-4682-postmerge-qualification/packages/coding-agent/src/internal-urls/terraform-property-ranking.ts:306` |
| 0.1% | 1.2ms | 0.1% | 1.2ms | `get` | `[native code]` |
| 0.1% | 1.2ms | 0.0% | 0us | `propertyTerms` | `/data/robin-GIT/worktrees/xcsh-4682-postmerge-qualification/packages/coding-agent/src/internal-urls/terraform-property-ranking.ts:71` |
| 0.1% | 1.2ms | 0.0% | 0us | `propertyTerms` | `/data/robin-GIT/worktrees/xcsh-4682-postmerge-qualification/packages/coding-agent/src/internal-urls/terraform-property-ranking.ts:62` |
| 0.1% | 1.2ms | 0.1% | 1.2ms | `propertyMatchesWorkloadArchitecture` | `/data/robin-GIT/worktrees/xcsh-4682-postmerge-qualification/packages/coding-agent/src/internal-urls/terraform-property-ranking.ts:138` |
| 0.1% | 1.2ms | 0.0% | 0us | `rankPropertyScope` | `/data/robin-GIT/worktrees/xcsh-4682-postmerge-qualification/packages/coding-agent/src/internal-urls/terraform-property-ranking.ts:620` |
| 0.1% | 1.2ms | 0.0% | 0us | `(anonymous)` | `/data/robin-GIT/worktrees/xcsh-4682-postmerge-qualification/packages/coding-agent/src/internal-urls/terraform-property-index.ts:313` |
| 0.1% | 1.2ms | 0.1% | 1.2ms | `join` | `[native code]` |
| 0.1% | 1.1ms | 0.1% | 1.1ms | `(anonymous)` | `/data/robin-GIT/worktrees/xcsh-4682-postmerge-qualification/packages/coding-agent/src/internal-urls/terraform-property-ranking.ts:745` |
| 0.1% | 1.1ms | 0.0% | 0us | `split` | `[native code]` |
| 0.1% | 1.1ms | 0.1% | 1.1ms | `(anonymous)` | `/data/robin-GIT/worktrees/xcsh-4682-postmerge-qualification/packages/coding-agent/src/internal-urls/terraform-property-ranking.ts:733` |
| 0.1% | 1.1ms | 0.0% | 0us | `selectPropertyDestinationInternal` | `/data/robin-GIT/worktrees/xcsh-4682-postmerge-qualification/packages/coding-agent/src/internal-urls/terraform-property-selection.ts:456` |
| 0.1% | 1.1ms | 0.0% | 0us | `(anonymous)` | `/data/robin-GIT/worktrees/xcsh-4682-postmerge-qualification/packages/coding-agent/src/internal-urls/terraform-property-ranking.ts:719` |
| 0.1% | 1.1ms | 0.0% | 0us | `(anonymous)` | `/data/robin-GIT/worktrees/xcsh-4682-postmerge-qualification/packages/coding-agent/src/internal-urls/terraform-property-index.ts:314` |
| 0.1% | 1.1ms | 0.0% | 0us | `(anonymous)` | `/data/robin-GIT/worktrees/xcsh-4682-postmerge-qualification/packages/coding-agent/src/internal-urls/terraform-property-index.ts:312` |
| 0.1% | 1.1ms | 0.1% | 1.1ms | `propertyTerms` | `/data/robin-GIT/worktrees/xcsh-4682-postmerge-qualification/packages/coding-agent/src/internal-urls/terraform-property-ranking.ts:70` |
| 0.1% | 1.1ms | 0.0% | 0us | `(anonymous)` | `/data/robin-GIT/worktrees/xcsh-4682-postmerge-qualification/packages/coding-agent/src/internal-urls/terraform-property-ranking.ts:661` |
| 0.1% | 1.1ms | 0.0% | 0us | `selectPropertyDestinationInternal` | `/data/robin-GIT/worktrees/xcsh-4682-postmerge-qualification/packages/coding-agent/src/internal-urls/terraform-property-selection.ts:258` |
| 0.1% | 1.1ms | 0.0% | 0us | `(anonymous)` | `/data/robin-GIT/worktrees/xcsh-4682-postmerge-qualification/packages/coding-agent/src/internal-urls/terraform-property-ranking.ts:652` |
| 0.1% | 1.1ms | 0.1% | 1.1ms | `weight` | `/data/robin-GIT/worktrees/xcsh-4682-postmerge-qualification/packages/coding-agent/src/internal-urls/terraform-property-ranking.ts:625` |
| 0.1% | 1.0ms | 0.0% | 0us | `propertyRequestedText` | `/data/robin-GIT/worktrees/xcsh-4682-postmerge-qualification/packages/coding-agent/src/internal-urls/terraform-property-ranking.ts:460` |
| 0.1% | 1.0ms | 0.1% | 1.0ms | `/\b(?:field\|attribute\|property\|parameter\|argument)\b\s+filters?\s+.+?\s+by\s+(.+)/i` | `[native code]` |
| 0.1% | 1.0ms | 0.0% | 0us | `(anonymous)` | `/data/robin-GIT/worktrees/xcsh-4682-postmerge-qualification/packages/coding-agent/src/internal-urls/terraform-property-ranking.ts:647` |
| 0.1% | 1.0ms | 0.0% | 0us | `(anonymous)` | `/data/robin-GIT/worktrees/xcsh-4682-postmerge-qualification/packages/coding-agent/src/internal-urls/terraform-property-ranking.ts:738` |
| 0.1% | 1.0ms | 0.1% | 1.0ms | `toFixed` | `[native code]` |
| 0.1% | 1.0ms | 0.1% | 1.0ms | `/\bfor\b(?!\s+[a-z]*(?:tion\|sion\|ing)\b)\|\breferenced in\b\|\bto\s+(?:handle\|match\|configure\|enable\|provide)\b\|\bwhen\s+(?:declaring\|configuring\|reading)\b\|\bof\s+(?:an? \|the )?(?:existing \|managed )?(?:resource\|load balancer\|site\|object)\b/i` | `[native code]` |
| 0.1% | 1.0ms | 0.1% | 1.0ms | `propertyRequestedText` | `/data/robin-GIT/worktrees/xcsh-4682-postmerge-qualification/packages/coding-agent/src/internal-urls/terraform-property-ranking.ts:511` |
| 0.1% | 1.0ms | 0.1% | 1.0ms | ``/\b(under\|within\|inside\|schema path\|branch\|path\|or\|and\|locate\|find\|point me to\|where is\|where are\|where do i put\|where do\|where does\|i need)\s+(?:(?:the\|its)\s+)?(`?)([a-z][a-z0-9_.-]*\.[a-z0-9_.-]+)\2/g`` | `[native code]` |
| 0.1% | 1.0ms | 0.1% | 1.0ms | `propertyRequestedText` | `/data/robin-GIT/worktrees/xcsh-4682-postmerge-qualification/packages/coding-agent/src/internal-urls/terraform-property-ranking.ts` |
| 0.1% | 1.0ms | 0.0% | 0us | `searchPropertyIndex` | `/data/robin-GIT/worktrees/xcsh-4682-postmerge-qualification/packages/coding-agent/src/internal-urls/terraform-property-index.ts:254` |
| 0.1% | 1.0ms | 0.1% | 1.0ms | `propertyValueLookup` | `/data/robin-GIT/worktrees/xcsh-4682-postmerge-qualification/packages/coding-agent/src/internal-urls/terraform-property-ranking.ts:404` |
| 0.1% | 1.0ms | 0.0% | 0us | `selectPropertyDestinationInternal` | `/data/robin-GIT/worktrees/xcsh-4682-postmerge-qualification/packages/coding-agent/src/internal-urls/terraform-property-selection.ts:230` |
| 0.1% | 1.0ms | 0.0% | 0us | `identifiersFor` | `/data/robin-GIT/worktrees/xcsh-4682-postmerge-qualification/packages/coding-agent/src/internal-urls/terraform-property-selection.ts:140` |
| 0.1% | 1.0ms | 0.0% | 0us | `(anonymous)` | `/data/robin-GIT/worktrees/xcsh-4682-postmerge-qualification/packages/coding-agent/src/internal-urls/terraform-property-selection.ts:230` |
| 0.1% | 1.0ms | 0.0% | 0us | `identifiersMatch` | `/data/robin-GIT/worktrees/xcsh-4682-postmerge-qualification/packages/coding-agent/src/internal-urls/terraform-property-selection.ts:142` |
| 0.1% | 994us | 0.1% | 994us | `propertyRequestsBlock` | `/data/robin-GIT/worktrees/xcsh-4682-postmerge-qualification/packages/coding-agent/src/internal-urls/terraform-property-ranking.ts:376` |
| 0.1% | 983us | 0.1% | 983us | `propertyTerms` | `/data/robin-GIT/worktrees/xcsh-4682-postmerge-qualification/packages/coding-agent/src/internal-urls/terraform-property-selection.ts` |
| 0.1% | 975us | 0.0% | 0us | `propertyTerms` | `/data/robin-GIT/worktrees/xcsh-4682-postmerge-qualification/packages/coding-agent/src/internal-urls/terraform-property-ranking.ts:59` |
| 0.1% | 975us | 0.1% | 975us | `/regular expressions?/g` | `[native code]` |
| 0.1% | 973us | 0.1% | 973us | `propertyRequestedText` | `/data/robin-GIT/worktrees/xcsh-4682-postmerge-qualification/packages/coding-agent/src/internal-urls/terraform-property-ranking.ts:535` |
| 0.1% | 973us | 0.1% | 973us | `(anonymous)` | `/data/robin-GIT/worktrees/xcsh-4682-postmerge-qualification/packages/coding-agent/src/internal-urls/terraform-property-ranking.ts:631` |
| 0.1% | 968us | 0.1% | 968us | `/\b(?:specify\|set\|provide\|supply)\b\s+(?!(?:(?:an?\|the)\s+)?(?:xcsh_\|resource\b\|data[ -]source\b\|provider\b))(.+)/i` | `[native code]` |
| 0.1% | 968us | 0.0% | 0us | `propertyRequestedText` | `/data/robin-GIT/worktrees/xcsh-4682-postmerge-qualification/packages/coding-agent/src/internal-urls/terraform-property-ranking.ts:479` |
| 0.1% | 958us | 0.0% | 0us | `selectPropertyDestinationInternal` | `/data/robin-GIT/worktrees/xcsh-4682-postmerge-qualification/packages/coding-agent/src/internal-urls/terraform-property-selection.ts:358` |
| 0.1% | 954us | 0.1% | 954us | `(anonymous)` | `/data/robin-GIT/worktrees/xcsh-4682-postmerge-qualification/packages/coding-agent/src/internal-urls/terraform-property-ranking.ts:726` |
| 0.1% | 950us | 0.1% | 950us | `exec` | `[native code]` |
| 0.1% | 942us | 0.1% | 942us | `propertyRequestedText` | `/data/robin-GIT/worktrees/xcsh-4682-postmerge-qualification/packages/coding-agent/src/internal-urls/terraform-property-ranking.ts:555` |
| 0.1% | 941us | 0.0% | 0us | `find` | `[native code]` |
| 0.1% | 941us | 0.0% | 0us | `selectPropertyDestinationInternal` | `/data/robin-GIT/worktrees/xcsh-4682-postmerge-qualification/packages/coding-agent/src/internal-urls/terraform-property-selection.ts:549` |
| 0.1% | 941us | 0.0% | 0us | `(anonymous)` | `/data/robin-GIT/worktrees/xcsh-4682-postmerge-qualification/packages/coding-agent/src/internal-urls/terraform-property-selection.ts:614` |
| 0.1% | 937us | 0.1% | 937us | `(anonymous)` | `/data/robin-GIT/worktrees/xcsh-4682-postmerge-qualification/packages/coding-agent/src/internal-urls/terraform-property-index.ts:323` |
| 0.1% | 926us | 0.1% | 926us | `propertyConflictingNamedScope` | `/data/robin-GIT/worktrees/xcsh-4682-postmerge-qualification/packages/coding-agent/src/internal-urls/terraform-property-ranking.ts:325` |
| 0.1% | 926us | 0.0% | 0us | `selectPropertyDestinationInternal` | `/data/robin-GIT/worktrees/xcsh-4682-postmerge-qualification/packages/coding-agent/src/internal-urls/terraform-property-selection.ts:87` |
| 0.1% | 923us | 0.0% | 0us | `propertyQueryTerms` | `/data/robin-GIT/worktrees/xcsh-4682-postmerge-qualification/packages/coding-agent/src/internal-urls/terraform-property-selection.ts:75` |
| 0.1% | 923us | 0.0% | 0us | `selectPropertyDestinationInternal` | `/data/robin-GIT/worktrees/xcsh-4682-postmerge-qualification/packages/coding-agent/src/internal-urls/terraform-property-selection.ts:325` |
| 0.1% | 923us | 0.1% | 923us | `propertyTerms` | `/data/robin-GIT/worktrees/xcsh-4682-postmerge-qualification/packages/coding-agent/src/internal-urls/terraform-property-ranking.ts:53` |
| 0.1% | 922us | 0.0% | 0us | `flatIntoArrayWithCallback` | `[native code]` |
| 0.1% | 922us | 0.0% | 0us | `searchPropertyIndex` | `/data/robin-GIT/worktrees/xcsh-4682-postmerge-qualification/packages/coding-agent/src/internal-urls/terraform-property-index.ts:257` |
| 0.1% | 922us | 0.1% | 922us | `flatIntoArray` | `[native code]` |
| 0.1% | 917us | 0.0% | 0us | `selectPropertyDestinationInternal` | `/data/robin-GIT/worktrees/xcsh-4682-postmerge-qualification/packages/coding-agent/src/internal-urls/terraform-property-selection.ts:530` |
| 0.1% | 917us | 0.0% | 0us | `every` | `[native code]` |
| 0.1% | 911us | 0.1% | 911us | `propertyQueryTerms` | `/data/robin-GIT/worktrees/xcsh-4682-postmerge-qualification/packages/coding-agent/src/internal-urls/terraform-property-ranking.ts` |
| 0.1% | 911us | 0.0% | 0us | `searchPropertyIndex` | `/data/robin-GIT/worktrees/xcsh-4682-postmerge-qualification/packages/coding-agent/src/internal-urls/terraform-property-index.ts:193` |
| 0.1% | 876us | 0.1% | 876us | `replace` | `[native code]` |

## Function Details

### `(anonymous)`
`/data/robin-GIT/worktrees/xcsh-4682-postmerge-qualification/packages/coding-agent/src/internal-urls/terraform-property-selection.ts:245` | Self: 32.9% (240.5ms) | Total: 51.7% (378.4ms) | Samples: 222

**Called by:**
- `some` (349)

**Calls:**
- `propertyTerms` (66)
- `propertyTerms` (58)
- `propertyTerms` (3)

### `all`
`[native code]` | Self: 17.3% (126.7ms) | Total: 17.3% (126.7ms) | Samples: 120

**Called by:**
- `searchPropertyIndex` (103)
- `searchPropertyIndex` (12)
- `searchPropertyIndex` (4)
- `searchPropertyIndex` (1)

### `propertyTerms`
`/data/robin-GIT/worktrees/xcsh-4682-postmerge-qualification/packages/coding-agent/src/internal-urls/terraform-property-selection.ts:70` | Self: 9.8% (72.1ms) | Total: 9.8% (72.1ms) | Samples: 66

**Called by:**
- `(anonymous)` (66)

### `propertyTerms`
`/data/robin-GIT/worktrees/xcsh-4682-postmerge-qualification/packages/coding-agent/src/internal-urls/terraform-property-selection.ts:65` | Self: 8.5% (62.4ms) | Total: 8.7% (63.7ms) | Samples: 58

**Called by:**
- `(anonymous)` (58)
- `rawContradicts` (1)

**Calls:**
- `get` (1)

### `(anonymous)`
`/data/robin-GIT/worktrees/xcsh-4682-postmerge-qualification/packages/coding-agent/src/internal-urls/terraform-property-selection.ts:250` | Self: 3.8% (28.0ms) | Total: 3.8% (28.0ms) | Samples: 27

**Called by:**
- `some` (27)

### `performIteration`
`[native code]` | Self: 3.3% (24.1ms) | Total: 3.8% (28.2ms) | Samples: 22

**Called by:**
- `(anonymous)` (24)
- `schemaPathMentions` (2)

**Calls:**
- `next` (4)

### `(module)`
`/data/robin-GIT/worktrees/xcsh-4682-postmerge-qualification/packages/coding-agent/src/internal-urls/terraform-property-ranking.ts:17` | Self: 2.6% (19.4ms) | Total: 2.6% (19.4ms) | Samples: 1

### `Set`
`[native code]` | Self: 1.6% (11.9ms) | Total: 1.6% (11.9ms) | Samples: 11

**Called by:**
- `(anonymous)` (6)
- `(anonymous)` (2)
- `rawContradicts` (2)
- `propertyTerms` (1)

### `includes`
`[native code]` | Self: 0.9% (6.9ms) | Total: 0.9% (6.9ms) | Samples: 6

**Called by:**
- `(anonymous)` (2)
- `(anonymous)` (2)
- `(anonymous)` (1)
- `selectPropertyDestinationInternal` (1)

### `filter`
`[native code]` | Self: 0.8% (6.2ms) | Total: 67.8% (496.1ms) | Samples: 6

**Called by:**
- `selectPropertyDestinationInternal` (420)
- `selectPropertyDestinationInternal` (21)
- `(anonymous)` (5)
- `selectPropertyDestinationInternal` (3)
- `selectPropertyDestinationInternal` (2)
- `rankPropertyScope` (1)
- `selectPropertyDestinationInternal` (1)
- `(anonymous)` (1)
- `selectPropertyDestinationInternal` (1)
- `(anonymous)` (1)
- `identifiersFor` (1)
- `propertyTerms` (1)

**Calls:**
- `(anonymous)` (410)
- `(anonymous)` (19)
- `(anonymous)` (6)
- `(anonymous)` (4)
- `(anonymous)` (3)
- `(anonymous)` (2)
- `(anonymous)` (2)
- `(anonymous)` (2)
- `propertyMatchesWorkloadArchitecture` (1)
- `(anonymous)` (1)
- `(anonymous)` (1)
- `(anonymous)` (1)

### `parse`
`[native code]` | Self: 0.8% (5.9ms) | Total: 0.8% (5.9ms) | Samples: 5

**Called by:**
- `(anonymous)` (1)
- `(anonymous)` (1)
- `(anonymous)` (1)
- `(anonymous)` (1)
- `(anonymous)` (1)

### `some`
`[native code]` | Self: 0.7% (5.4ms) | Total: 56.4% (412.8ms) | Samples: 5

**Called by:**
- `(anonymous)` (381)
- `(anonymous)` (1)

**Calls:**
- `(anonymous)` (349)
- `(anonymous)` (27)
- `(anonymous)` (1)

### `(anonymous)`
`/data/robin-GIT/worktrees/xcsh-4682-postmerge-qualification/packages/coding-agent/src/internal-urls/terraform-property-selection.ts:244` | Self: 0.7% (5.1ms) | Total: 60.6% (443.1ms) | Samples: 5

**Called by:**
- `filter` (410)

**Calls:**
- `some` (381)
- `performIteration` (24)

### `copyDataProperties`
`[native code]` | Self: 0.6% (4.9ms) | Total: 0.6% (4.9ms) | Samples: 5

**Called by:**
- `(anonymous)` (2)
- `(anonymous)` (1)
- `(anonymous)` (1)
- `(anonymous)` (1)

### `propertyValueLookup`
`/data/robin-GIT/worktrees/xcsh-4682-postmerge-qualification/packages/coding-agent/src/internal-urls/terraform-property-ranking.ts:414` | Self: 0.5% (4.3ms) | Total: 0.5% (4.3ms) | Samples: 4

**Called by:**
- `propertyRequestedText` (4)

### `map`
`[native code]` | Self: 0.5% (4.0ms) | Total: 11.5% (84.1ms) | Samples: 4

**Called by:**
- `rankPropertyScope` (59)
- `searchPropertyIndex` (10)
- `propertyTerms` (5)
- `searchPropertyIndex` (3)
- `propertyExplicitSchemaPaths` (1)

**Calls:**
- `(anonymous)` (22)
- `(anonymous)` (7)
- `(anonymous)` (6)
- `(anonymous)` (3)
- `(anonymous)` (3)
- `(anonymous)` (3)
- `(anonymous)` (3)
- `(anonymous)` (2)
- `(anonymous)` (2)
- `(anonymous)` (2)
- `(anonymous)` (2)
- `(anonymous)` (2)
- `(anonymous)` (2)
- `(anonymous)` (2)
- `(anonymous)` (1)
- `(anonymous)` (1)
- `(anonymous)` (1)
- `(anonymous)` (1)
- `(anonymous)` (1)
- `(anonymous)` (1)
- `(anonymous)` (1)
- `(anonymous)` (1)
- `(anonymous)` (1)
- `(anonymous)` (1)
- `(anonymous)` (1)
- `(anonymous)` (1)
- `(anonymous)` (1)

### `match`
`[native code]` | Self: 0.4% (3.3ms) | Total: 0.6% (4.4ms) | Samples: 3

**Called by:**
- `propertyTerms` (2)
- `propertyRequestedText` (1)
- `propertyRequestedText` (1)

**Calls:**
- `/\b(?:field\|attribute\|property\|parameter\|argument)\b\s+filters?\s+.+?\s+by\s+(.+)/i` (1)

### `propertyRequestedText`
`/data/robin-GIT/worktrees/xcsh-4682-postmerge-qualification/packages/coding-agent/src/internal-urls/terraform-property-ranking.ts:552` | Self: 0.4% (3.3ms) | Total: 0.5% (4.3ms) | Samples: 3

**Called by:**
- `propertyRequestsCollection` (4)

**Calls:**
- `/\bfor\b(?!\s+[a-z]*(?:tion\|sion\|ing)\b)\|\breferenced in\b\|\bto\s+(?:handle\|match\|configure\|enable\|provide)\b\|\bwhen\s+(?:declaring\|configuring\|reading)\b\|\bof\s+(?:an? \|the )?(?:existing \|managed )?(?:resource\|load balancer\|site\|object)\b/i` (1)

### `(anonymous)`
`/data/robin-GIT/worktrees/xcsh-4682-postmerge-qualification/packages/coding-agent/src/internal-urls/terraform-property-ranking.ts` | Self: 0.4% (3.2ms) | Total: 0.4% (3.2ms) | Samples: 3

**Called by:**
- `filter` (2)
- `map` (1)

### `(anonymous)`
`/data/robin-GIT/worktrees/xcsh-4682-postmerge-qualification/packages/coding-agent/src/internal-urls/terraform-property-ranking.ts:66` | Self: 0.4% (3.2ms) | Total: 0.4% (3.2ms) | Samples: 3

**Called by:**
- `map` (3)

### `(anonymous)`
`/data/robin-GIT/worktrees/xcsh-4682-postmerge-qualification/packages/coding-agent/src/internal-urls/terraform-property-ranking.ts:713` | Self: 0.4% (3.2ms) | Total: 0.4% (3.2ms) | Samples: 3

**Called by:**
- `map` (3)

### `next`
`[native code]` | Self: 0.4% (3.0ms) | Total: 0.5% (4.0ms) | Samples: 3

**Called by:**
- `performIteration` (4)

**Calls:**
- ``/\b(under\|within\|inside\|schema path\|branch\|path\|or\|and\|locate\|find\|point me to\|where is\|where are\|where do i put\|where do\|where does\|i need)\s+(?:(?:the\|its)\s+)?(`?)([a-z][a-z0-9_.-]*\.[a-z0-9_.-]+)\2/g`` (1)

### `(anonymous)`
`/data/robin-GIT/worktrees/xcsh-4682-postmerge-qualification/packages/coding-agent/src/internal-urls/terraform-property-selection.ts` | Self: 0.3% (2.8ms) | Total: 0.3% (2.8ms) | Samples: 3

**Called by:**
- `filter` (1)
- `some` (1)
- `every` (1)

### `(anonymous)`
`/data/robin-GIT/worktrees/xcsh-4682-postmerge-qualification/packages/coding-agent/src/internal-urls/terraform-property-ranking.ts:730` | Self: 0.3% (2.3ms) | Total: 1.1% (8.0ms) | Samples: 2

**Called by:**
- `map` (7)

**Calls:**
- `filter` (5)

### `propertyRequestsBlock`
`/data/robin-GIT/worktrees/xcsh-4682-postmerge-qualification/packages/coding-agent/src/internal-urls/terraform-property-ranking.ts:384` | Self: 0.3% (2.2ms) | Total: 0.3% (2.2ms) | Samples: 2

**Called by:**
- `propertyRequestedText` (2)

### `(anonymous)`
`/data/robin-GIT/worktrees/xcsh-4682-postmerge-qualification/packages/coding-agent/src/internal-urls/terraform-property-ranking.ts:639` | Self: 0.3% (2.2ms) | Total: 0.4% (3.4ms) | Samples: 2

**Called by:**
- `map` (3)

**Calls:**
- `/\bto\s+(?:handle\|match\|configure\|enable\|provide)\b\|\bwhen\s+(?:declaring\|configuring\|reading)\b\|\bof\s+(?:an? \|the )?(?:existing \|managed )?(?:resource\|load balancer\|site\|object)\b/i` (1)

### `propertyRequestedText`
`/data/robin-GIT/worktrees/xcsh-4682-postmerge-qualification/packages/coding-agent/src/internal-urls/terraform-property-ranking.ts:486` | Self: 0.3% (2.2ms) | Total: 0.3% (2.2ms) | Samples: 2

**Called by:**
- `(anonymous)` (1)
- `propertyRequestsCollection` (1)

### `(anonymous)`
`/data/robin-GIT/worktrees/xcsh-4682-postmerge-qualification/packages/coding-agent/src/internal-urls/terraform-property-ranking.ts:699` | Self: 0.3% (2.1ms) | Total: 0.3% (2.1ms) | Samples: 2

**Called by:**
- `map` (2)

### `/\bused\s+to\b\|\bat\s+which\b\|\bwhen\s+(?:handling\|processing\|matching\|calling\|invoking\|executing)\b/i`
`[native code]` | Self: 0.2% (2.1ms) | Total: 0.2% (2.1ms) | Samples: 2

**Called by:**
- `propertyRequestedText` (1)
- `split` (1)

### `propertyTerms`
`/data/robin-GIT/worktrees/xcsh-4682-postmerge-qualification/packages/coding-agent/src/internal-urls/terraform-property-ranking.ts:60` | Self: 0.2% (2.1ms) | Total: 0.5% (4.3ms) | Samples: 2

**Called by:**
- `propertyTerms` (4)

**Calls:**
- `match` (2)

### `propertyRequestedText`
`/data/robin-GIT/worktrees/xcsh-4682-postmerge-qualification/packages/coding-agent/src/internal-urls/terraform-property-ranking.ts:463` | Self: 0.2% (2.0ms) | Total: 0.4% (3.2ms) | Samples: 2

**Called by:**
- `propertyRequestsCollection` (2)
- `(anonymous)` (1)

**Calls:**
- `match` (1)

### `has`
`[native code]` | Self: 0.2% (2.0ms) | Total: 0.2% (2.0ms) | Samples: 2

**Called by:**
- `selectPropertyDestinationInternal` (2)

### `(anonymous)`
`/data/robin-GIT/worktrees/xcsh-4682-postmerge-qualification/packages/coding-agent/src/internal-urls/terraform-property-index.ts:275` | Self: 0.2% (2.0ms) | Total: 0.2% (2.0ms) | Samples: 2

**Called by:**
- `map` (2)

### `propertyTerms`
`/data/robin-GIT/worktrees/xcsh-4682-postmerge-qualification/packages/coding-agent/src/internal-urls/terraform-property-ranking.ts:57` | Self: 0.2% (1.9ms) | Total: 0.3% (2.7ms) | Samples: 2

**Called by:**
- `propertyTerms` (3)

**Calls:**
- `replace` (1)

### `prepare`
`[native code]` | Self: 0.1% (1.2ms) | Total: 0.1% (1.2ms) | Samples: 1

**Called by:**
- `[prepareOwned]` (1)

### `propertyRequestedText`
`/data/robin-GIT/worktrees/xcsh-4682-postmerge-qualification/packages/coding-agent/src/internal-urls/terraform-property-ranking.ts:550` | Self: 0.1% (1.2ms) | Total: 0.1% (1.2ms) | Samples: 1

**Called by:**
- `propertyRequestsCollection` (1)

### `/\b(?:example\|usage\|guidance)\b/i`
`[native code]` | Self: 0.1% (1.2ms) | Total: 0.1% (1.2ms) | Samples: 1

**Called by:**
- `propertyValueLookup` (1)

### `propertyRequestsBlock`
`/data/robin-GIT/worktrees/xcsh-4682-postmerge-qualification/packages/coding-agent/src/internal-urls/terraform-property-ranking.ts:363` | Self: 0.1% (1.2ms) | Total: 0.1% (1.2ms) | Samples: 1

**Called by:**
- `propertyRequestedText` (1)

### `interpretTerraformLifecycle`
`/data/robin-GIT/worktrees/xcsh-4682-postmerge-qualification/packages/coding-agent/src/internal-urls/terraform-lifecycle.ts` | Self: 0.1% (1.2ms) | Total: 0.1% (1.2ms) | Samples: 1

**Called by:**
- `selectPropertyDestinationInternal` (1)

### `(anonymous)`
`/data/robin-GIT/worktrees/xcsh-4682-postmerge-qualification/packages/coding-agent/src/internal-urls/terraform-property-ranking.ts:656` | Self: 0.1% (1.2ms) | Total: 0.1% (1.2ms) | Samples: 1

**Called by:**
- `map` (1)

### `selectPropertyDestinationInternal`
`/data/robin-GIT/worktrees/xcsh-4682-postmerge-qualification/packages/coding-agent/src/internal-urls/terraform-property-selection.ts` | Self: 0.1% (1.2ms) | Total: 0.1% (1.2ms) | Samples: 1

**Called by:**
- `selectPropertyDestination` (1)

### `/\bto\s+(?:handle\|match\|configure\|enable\|provide)\b\|\bwhen\s+(?:declaring\|configuring\|reading)\b\|\bof\s+(?:an? \|the )?(?:existing \|managed )?(?:resource\|load balancer\|site\|object)\b/i`
`[native code]` | Self: 0.1% (1.2ms) | Total: 0.1% (1.2ms) | Samples: 1

**Called by:**
- `(anonymous)` (1)

### `rawContradicts`
`/data/robin-GIT/worktrees/xcsh-4682-postmerge-qualification/packages/coding-agent/src/internal-urls/terraform-property-selection.ts` | Self: 0.1% (1.2ms) | Total: 0.1% (1.2ms) | Samples: 1

**Called by:**
- `(anonymous)` (1)

### `/\bxcsh_[a-z0-9_]+\b\|\bto\s+(?:read\|fetch\|retrieve\|inspect\|look up\|lookup)\b/i`
`[native code]` | Self: 0.1% (1.2ms) | Total: 0.1% (1.2ms) | Samples: 1

**Called by:**
- `propertyRequestedText` (1)

### `propertyExcludedSchemaIdentifiers`
`/data/robin-GIT/worktrees/xcsh-4682-postmerge-qualification/packages/coding-agent/src/internal-urls/terraform-property-ranking.ts:306` | Self: 0.1% (1.2ms) | Total: 0.1% (1.2ms) | Samples: 1

**Called by:**
- `selectPropertyDestinationInternal` (1)

### `get`
`[native code]` | Self: 0.1% (1.2ms) | Total: 0.1% (1.2ms) | Samples: 1

**Called by:**
- `propertyTerms` (1)

### `(anonymous)`
`/data/robin-GIT/worktrees/xcsh-4682-postmerge-qualification/packages/coding-agent/src/internal-urls/terraform-property-selection.ts:397` | Self: 0.1% (1.2ms) | Total: 0.3% (2.4ms) | Samples: 1

**Called by:**
- `filter` (2)

**Calls:**
- `join` (1)

### `propertyMatchesWorkloadArchitecture`
`/data/robin-GIT/worktrees/xcsh-4682-postmerge-qualification/packages/coding-agent/src/internal-urls/terraform-property-ranking.ts:138` | Self: 0.1% (1.2ms) | Total: 0.1% (1.2ms) | Samples: 1

**Called by:**
- `filter` (1)

### `join`
`[native code]` | Self: 0.1% (1.2ms) | Total: 0.1% (1.2ms) | Samples: 1

**Called by:**
- `(anonymous)` (1)

### `(anonymous)`
`/data/robin-GIT/worktrees/xcsh-4682-postmerge-qualification/packages/coding-agent/src/internal-urls/terraform-property-ranking.ts:745` | Self: 0.1% (1.1ms) | Total: 0.1% (1.1ms) | Samples: 1

**Called by:**
- `sort` (1)

### `propertyTerms`
`/data/robin-GIT/worktrees/xcsh-4682-postmerge-qualification/packages/coding-agent/src/internal-urls/terraform-property-ranking.ts:64` | Self: 0.1% (1.1ms) | Total: 0.8% (6.4ms) | Samples: 1

**Called by:**
- `propertyTerms` (6)

**Calls:**
- `map` (5)

### `(anonymous)`
`/data/robin-GIT/worktrees/xcsh-4682-postmerge-qualification/packages/coding-agent/src/internal-urls/terraform-property-ranking.ts:733` | Self: 0.1% (1.1ms) | Total: 0.1% (1.1ms) | Samples: 1

**Called by:**
- `filter` (1)

### `propertyValueLookup`
`/data/robin-GIT/worktrees/xcsh-4682-postmerge-qualification/packages/coding-agent/src/internal-urls/terraform-property-ranking.ts:409` | Self: 0.1% (1.1ms) | Total: 0.2% (2.1ms) | Samples: 1

**Called by:**
- `propertyRequestedText` (2)

**Calls:**
- `exec` (1)

### `propertyTerms`
`/data/robin-GIT/worktrees/xcsh-4682-postmerge-qualification/packages/coding-agent/src/internal-urls/terraform-property-ranking.ts:70` | Self: 0.1% (1.1ms) | Total: 0.1% (1.1ms) | Samples: 1

**Called by:**
- `propertyTerms` (1)

### `sort`
`[native code]` | Self: 0.1% (1.1ms) | Total: 0.4% (3.2ms) | Samples: 1

**Called by:**
- `searchPropertyIndex` (1)
- `selectPropertyDestinationInternal` (1)
- `(module)` (1)

**Calls:**
- `(anonymous)` (1)
- `(anonymous)` (1)

### `weight`
`/data/robin-GIT/worktrees/xcsh-4682-postmerge-qualification/packages/coding-agent/src/internal-urls/terraform-property-ranking.ts:625` | Self: 0.1% (1.1ms) | Total: 0.1% (1.1ms) | Samples: 1

**Called by:**
- `(anonymous)` (1)

### `(anonymous)`
`/data/robin-GIT/worktrees/xcsh-4682-postmerge-qualification/packages/coding-agent/src/internal-urls/terraform-property-index.ts:310` | Self: 0.1% (1.1ms) | Total: 0.2% (2.0ms) | Samples: 1

**Called by:**
- `map` (2)

**Calls:**
- `copyDataProperties` (1)

### `/\b(?:field\|attribute\|property\|parameter\|argument)\b\s+filters?\s+.+?\s+by\s+(.+)/i`
`[native code]` | Self: 0.1% (1.0ms) | Total: 0.1% (1.0ms) | Samples: 1

**Called by:**
- `match` (1)

### `(anonymous)`
`/data/robin-GIT/worktrees/xcsh-4682-postmerge-qualification/packages/coding-agent/src/internal-urls/terraform-property-ranking.ts:655` | Self: 0.1% (1.0ms) | Total: 0.2% (2.1ms) | Samples: 1

**Called by:**
- `map` (2)

**Calls:**
- `filter` (1)

### `toFixed`
`[native code]` | Self: 0.1% (1.0ms) | Total: 0.1% (1.0ms) | Samples: 1

**Called by:**
- `(anonymous)` (1)

### `/\bfor\b(?!\s+[a-z]*(?:tion\|sion\|ing)\b)\|\breferenced in\b\|\bto\s+(?:handle\|match\|configure\|enable\|provide)\b\|\bwhen\s+(?:declaring\|configuring\|reading)\b\|\bof\s+(?:an? \|the )?(?:existing \|managed )?(?:resource\|load balancer\|site\|object)\b/i`
`[native code]` | Self: 0.1% (1.0ms) | Total: 0.1% (1.0ms) | Samples: 1

**Called by:**
- `propertyRequestedText` (1)

### `propertyRequestedText`
`/data/robin-GIT/worktrees/xcsh-4682-postmerge-qualification/packages/coding-agent/src/internal-urls/terraform-property-ranking.ts:511` | Self: 0.1% (1.0ms) | Total: 0.1% (1.0ms) | Samples: 1

**Called by:**
- `(anonymous)` (1)

### ``/\b(under\|within\|inside\|schema path\|branch\|path\|or\|and\|locate\|find\|point me to\|where is\|where are\|where do i put\|where do\|where does\|i need)\s+(?:(?:the\|its)\s+)?(`?)([a-z][a-z0-9_.-]*\.[a-z0-9_.-]+)\2/g``
`[native code]` | Self: 0.1% (1.0ms) | Total: 0.1% (1.0ms) | Samples: 1

**Called by:**
- `next` (1)

### `propertyRequestedText`
`/data/robin-GIT/worktrees/xcsh-4682-postmerge-qualification/packages/coding-agent/src/internal-urls/terraform-property-ranking.ts` | Self: 0.1% (1.0ms) | Total: 0.1% (1.0ms) | Samples: 1

**Called by:**
- `propertyRequestedType` (1)

### `propertyValueLookup`
`/data/robin-GIT/worktrees/xcsh-4682-postmerge-qualification/packages/coding-agent/src/internal-urls/terraform-property-ranking.ts:404` | Self: 0.1% (1.0ms) | Total: 0.1% (1.0ms) | Samples: 1

**Called by:**
- `propertyRequestedText` (1)

### `(anonymous)`
`/data/robin-GIT/worktrees/xcsh-4682-postmerge-qualification/packages/coding-agent/src/internal-urls/terraform-property-ranking.ts:680` | Self: 0.1% (1.0ms) | Total: 3.2% (23.6ms) | Samples: 1

**Called by:**
- `map` (22)

**Calls:**
- `propertyNamesCollection` (21)

### `searchPropertyIndex`
`/data/robin-GIT/worktrees/xcsh-4682-postmerge-qualification/packages/coding-agent/src/internal-urls/terraform-property-index.ts:274` | Self: 0.1% (1.0ms) | Total: 0.5% (3.9ms) | Samples: 1

**Called by:**
- `(module)` (4)

**Calls:**
- `map` (3)

### `propertyNamesCollection`
`/data/robin-GIT/worktrees/xcsh-4682-postmerge-qualification/packages/coding-agent/src/internal-urls/terraform-property-ranking.ts:564` | Self: 0.1% (1.0ms) | Total: 3.6% (26.8ms) | Samples: 1

**Called by:**
- `(anonymous)` (21)
- `(anonymous)` (4)

**Calls:**
- `propertyRequestsCollection` (24)

### `propertyRequestsBlock`
`/data/robin-GIT/worktrees/xcsh-4682-postmerge-qualification/packages/coding-agent/src/internal-urls/terraform-property-ranking.ts:376` | Self: 0.1% (994us) | Total: 0.1% (994us) | Samples: 1

**Called by:**
- `propertyRequestedText` (1)

### `propertyTerms`
`/data/robin-GIT/worktrees/xcsh-4682-postmerge-qualification/packages/coding-agent/src/internal-urls/terraform-property-selection.ts` | Self: 0.1% (983us) | Total: 0.1% (983us) | Samples: 1

**Called by:**
- `rawContradicts` (1)

### `/regular expressions?/g`
`[native code]` | Self: 0.1% (975us) | Total: 0.1% (975us) | Samples: 1

**Called by:**
- `propertyTerms` (1)

### `(anonymous)`
`/data/robin-GIT/worktrees/xcsh-4682-postmerge-qualification/packages/coding-agent/src/internal-urls/terraform-property-ranking.ts:631` | Self: 0.1% (973us) | Total: 0.1% (973us) | Samples: 1

**Called by:**
- `map` (1)

### `propertyRequestedText`
`/data/robin-GIT/worktrees/xcsh-4682-postmerge-qualification/packages/coding-agent/src/internal-urls/terraform-property-ranking.ts:535` | Self: 0.1% (973us) | Total: 0.1% (973us) | Samples: 1

**Called by:**
- `(anonymous)` (1)

### `/\b(?:specify\|set\|provide\|supply)\b\s+(?!(?:(?:an?\|the)\s+)?(?:xcsh_\|resource\b\|data[ -]source\b\|provider\b))(.+)/i`
`[native code]` | Self: 0.1% (968us) | Total: 0.1% (968us) | Samples: 1

**Called by:**
- `propertyRequestedText` (1)

### `(anonymous)`
`/data/robin-GIT/worktrees/xcsh-4682-postmerge-qualification/packages/coding-agent/src/internal-urls/terraform-property-ranking.ts:726` | Self: 0.1% (954us) | Total: 0.1% (954us) | Samples: 1

**Called by:**
- `map` (1)

### `exec`
`[native code]` | Self: 0.1% (950us) | Total: 0.1% (950us) | Samples: 1

**Called by:**
- `propertyValueLookup` (1)

### `propertyRequestedText`
`/data/robin-GIT/worktrees/xcsh-4682-postmerge-qualification/packages/coding-agent/src/internal-urls/terraform-property-ranking.ts:555` | Self: 0.1% (942us) | Total: 0.1% (942us) | Samples: 1

**Called by:**
- `propertyRequestsCollection` (1)

### `propertyRequestedText`
`/data/robin-GIT/worktrees/xcsh-4682-postmerge-qualification/packages/coding-agent/src/internal-urls/terraform-property-ranking.ts:454` | Self: 0.1% (942us) | Total: 0.7% (5.4ms) | Samples: 1

**Called by:**
- `propertyRequestsCollection` (4)
- `(anonymous)` (1)

**Calls:**
- `propertyRequestsBlock` (2)
- `propertyRequestsBlock` (1)
- `propertyRequestsBlock` (1)

### `(anonymous)`
`/data/robin-GIT/worktrees/xcsh-4682-postmerge-qualification/packages/coding-agent/src/internal-urls/terraform-property-index.ts:323` | Self: 0.1% (937us) | Total: 0.1% (937us) | Samples: 1

**Called by:**
- `sort` (1)

### `propertyConflictingNamedScope`
`/data/robin-GIT/worktrees/xcsh-4682-postmerge-qualification/packages/coding-agent/src/internal-urls/terraform-property-ranking.ts:325` | Self: 0.1% (926us) | Total: 0.1% (926us) | Samples: 1

**Called by:**
- `selectPropertyDestinationInternal` (1)

### `propertyTerms`
`/data/robin-GIT/worktrees/xcsh-4682-postmerge-qualification/packages/coding-agent/src/internal-urls/terraform-property-ranking.ts:53` | Self: 0.1% (923us) | Total: 0.1% (923us) | Samples: 1

**Called by:**
- `propertyQueryTerms` (1)

### `flatIntoArray`
`[native code]` | Self: 0.1% (922us) | Total: 0.1% (922us) | Samples: 1

**Called by:**
- `flatIntoArrayWithCallback` (1)

### `propertyQueryTerms`
`/data/robin-GIT/worktrees/xcsh-4682-postmerge-qualification/packages/coding-agent/src/internal-urls/terraform-property-ranking.ts` | Self: 0.1% (911us) | Total: 0.1% (911us) | Samples: 1

**Called by:**
- `searchPropertyIndex` (1)

### `(anonymous)`
`/data/robin-GIT/worktrees/xcsh-4682-postmerge-qualification/packages/coding-agent/src/internal-urls/terraform-property-ranking.ts:649` | Self: 0.1% (894us) | Total: 0.3% (2.8ms) | Samples: 1

**Called by:**
- `map` (3)

**Calls:**
- `Set` (2)

### `propertyRequestedText`
`/data/robin-GIT/worktrees/xcsh-4682-postmerge-qualification/packages/coding-agent/src/internal-urls/terraform-property-ranking.ts:551` | Self: 0.1% (885us) | Total: 0.4% (3.0ms) | Samples: 1

**Called by:**
- `propertyRequestsCollection` (3)

**Calls:**
- `/\bused\s+to\b\|\bat\s+which\b\|\bwhen\s+(?:handling\|processing\|matching\|calling\|invoking\|executing)\b/i` (1)
- `split` (1)

### `replace`
`[native code]` | Self: 0.1% (876us) | Total: 0.1% (876us) | Samples: 1

**Called by:**
- `propertyTerms` (1)

### `propertyRequestedText`
`/data/robin-GIT/worktrees/xcsh-4682-postmerge-qualification/packages/coding-agent/src/internal-urls/terraform-property-ranking.ts:514` | Self: 0.0% (0us) | Total: 0.1% (1.2ms) | Samples: 0

**Called by:**
- `propertyRequestsCollection` (1)

**Calls:**
- `/\bxcsh_[a-z0-9_]+\b\|\bto\s+(?:read\|fetch\|retrieve\|inspect\|look up\|lookup)\b/i` (1)

### `propertyRequestedText`
`/data/robin-GIT/worktrees/xcsh-4682-postmerge-qualification/packages/coding-agent/src/internal-urls/terraform-property-ranking.ts:460` | Self: 0.0% (0us) | Total: 0.1% (1.0ms) | Samples: 0

**Called by:**
- `propertyRequestsCollection` (1)

**Calls:**
- `match` (1)

### `searchPropertyIndex`
`/data/robin-GIT/worktrees/xcsh-4682-postmerge-qualification/packages/coding-agent/src/internal-urls/terraform-property-index.ts:301` | Self: 0.0% (0us) | Total: 0.1% (1.2ms) | Samples: 0

**Called by:**
- `(module)` (1)

**Calls:**
- `all` (1)

### `[prepareOwned]`
`bun:sqlite:330` | Self: 0.0% (0us) | Total: 0.1% (1.2ms) | Samples: 0

**Called by:**
- `query` (1)

**Calls:**
- `prepare` (1)

### `propertyTerms`
`/data/robin-GIT/worktrees/xcsh-4682-postmerge-qualification/packages/coding-agent/src/internal-urls/terraform-property-ranking.ts:59` | Self: 0.0% (0us) | Total: 0.1% (975us) | Samples: 0

**Called by:**
- `propertyTerms` (1)

**Calls:**
- `/regular expressions?/g` (1)

### `selectPropertyDestinationInternal`
`/data/robin-GIT/worktrees/xcsh-4682-postmerge-qualification/packages/coding-agent/src/internal-urls/terraform-property-selection.ts:83` | Self: 0.0% (0us) | Total: 0.1% (1.2ms) | Samples: 0

**Called by:**
- `selectPropertyDestination` (1)

**Calls:**
- `propertyExcludedSchemaIdentifiers` (1)

### `(anonymous)`
`/data/robin-GIT/worktrees/xcsh-4682-postmerge-qualification/packages/coding-agent/src/internal-urls/terraform-property-ranking.ts:636` | Self: 0.0% (0us) | Total: 0.3% (2.2ms) | Samples: 0

**Called by:**
- `map` (2)

**Calls:**
- `includes` (2)

### `(anonymous)`
`/data/robin-GIT/worktrees/xcsh-4682-postmerge-qualification/packages/coding-agent/src/internal-urls/terraform-property-ranking.ts:732` | Self: 0.0% (0us) | Total: 0.3% (2.4ms) | Samples: 0

**Called by:**
- `filter` (2)

**Calls:**
- `includes` (2)

### `(module)`
`/tmp/terraform-expanded-profile.ts:1` | Self: 0.0% (0us) | Total: 97.3% (711.5ms) | Samples: 0

**Calls:**
- `selectPropertyDestination` (459)
- `searchPropertyIndex` (103)
- `searchPropertyIndex` (61)
- `searchPropertyIndex` (12)
- `searchPropertyIndex` (10)
- `searchPropertyIndex` (4)
- `searchPropertyIndex` (4)
- `searchPropertyIndex` (2)
- `searchPropertyIndex` (1)
- `searchPropertyIndex` (1)
- `searchPropertyIndex` (1)
- `sort` (1)
- `searchPropertyIndex` (1)
- `searchPropertyIndex` (1)

### `selectPropertyDestination`
`/data/robin-GIT/worktrees/xcsh-4682-postmerge-qualification/packages/coding-agent/src/internal-urls/terraform-property-selection.ts:648` | Self: 0.0% (0us) | Total: 67.9% (496.5ms) | Samples: 0

**Called by:**
- `(module)` (459)

**Calls:**
- `selectPropertyDestinationInternal` (420)
- `selectPropertyDestinationInternal` (21)
- `selectPropertyDestinationInternal` (3)
- `selectPropertyDestinationInternal` (2)
- `selectPropertyDestinationInternal` (2)
- `selectPropertyDestinationInternal` (1)
- `selectPropertyDestinationInternal` (1)
- `selectPropertyDestinationInternal` (1)
- `selectPropertyDestinationInternal` (1)
- `selectPropertyDestinationInternal` (1)
- `selectPropertyDestinationInternal` (1)
- `selectPropertyDestinationInternal` (1)
- `selectPropertyDestinationInternal` (1)
- `selectPropertyDestinationInternal` (1)
- `selectPropertyDestinationInternal` (1)
- `selectPropertyDestinationInternal` (1)

### `(anonymous)`
`/data/robin-GIT/worktrees/xcsh-4682-postmerge-qualification/packages/coding-agent/src/internal-urls/terraform-property-ranking.ts:661` | Self: 0.0% (0us) | Total: 0.1% (1.1ms) | Samples: 0

**Called by:**
- `map` (1)

**Calls:**
- `filter` (1)

### `(anonymous)`
`/data/robin-GIT/worktrees/xcsh-4682-postmerge-qualification/packages/coding-agent/src/internal-urls/terraform-property-index.ts:313` | Self: 0.0% (0us) | Total: 0.1% (1.2ms) | Samples: 0

**Called by:**
- `map` (1)

**Calls:**
- `parse` (1)

### `propertyRequestedType`
`/data/robin-GIT/worktrees/xcsh-4682-postmerge-qualification/packages/coding-agent/src/internal-urls/terraform-property-ranking.ts:223` | Self: 0.0% (0us) | Total: 0.2% (2.0ms) | Samples: 0

**Called by:**
- `searchPropertyIndex` (2)

**Calls:**
- `propertyRequestedText` (1)
- `propertyRequestedText` (1)

### `selectPropertyDestinationInternal`
`/data/robin-GIT/worktrees/xcsh-4682-postmerge-qualification/packages/coding-agent/src/internal-urls/terraform-property-selection.ts:232` | Self: 0.0% (0us) | Total: 0.2% (2.0ms) | Samples: 0

**Called by:**
- `selectPropertyDestination` (2)

**Calls:**
- `has` (2)

### `(anonymous)`
`/data/robin-GIT/worktrees/xcsh-4682-postmerge-qualification/packages/coding-agent/src/internal-urls/terraform-property-ranking.ts:626` | Self: 0.0% (0us) | Total: 0.8% (6.3ms) | Samples: 0

**Called by:**
- `map` (6)

**Calls:**
- `Set` (6)

### `rankPropertyScope`
`/data/robin-GIT/worktrees/xcsh-4682-postmerge-qualification/packages/coding-agent/src/internal-urls/terraform-property-ranking.ts:620` | Self: 0.0% (0us) | Total: 0.1% (1.2ms) | Samples: 0

**Called by:**
- `searchPropertyIndex` (1)

**Calls:**
- `filter` (1)

### `(anonymous)`
`/data/robin-GIT/worktrees/xcsh-4682-postmerge-qualification/packages/coding-agent/src/internal-urls/terraform-property-index.ts:312` | Self: 0.0% (0us) | Total: 0.1% (1.1ms) | Samples: 0

**Called by:**
- `map` (1)

**Calls:**
- `parse` (1)

### `selectPropertyDestinationInternal`
`/data/robin-GIT/worktrees/xcsh-4682-postmerge-qualification/packages/coding-agent/src/internal-urls/terraform-property-selection.ts:87` | Self: 0.0% (0us) | Total: 0.1% (926us) | Samples: 0

**Called by:**
- `selectPropertyDestination` (1)

**Calls:**
- `propertyConflictingNamedScope` (1)

### `propertyRequestedText`
`/data/robin-GIT/worktrees/xcsh-4682-postmerge-qualification/packages/coding-agent/src/internal-urls/terraform-property-ranking.ts:533` | Self: 0.0% (0us) | Total: 1.2% (8.7ms) | Samples: 0

**Called by:**
- `propertyRequestsCollection` (5)
- `propertyRequestedType` (1)
- `(anonymous)` (1)
- `searchPropertyIndex` (1)

**Calls:**
- `propertyValueLookup` (4)
- `propertyValueLookup` (2)
- `propertyValueLookup` (1)
- `propertyValueLookup` (1)

### `propertyValueLookup`
`/data/robin-GIT/worktrees/xcsh-4682-postmerge-qualification/packages/coding-agent/src/internal-urls/terraform-property-ranking.ts:413` | Self: 0.0% (0us) | Total: 0.1% (1.2ms) | Samples: 0

**Called by:**
- `propertyRequestedText` (1)

**Calls:**
- `/\b(?:example\|usage\|guidance)\b/i` (1)

### `propertyExplicitSchemaPaths`
`/data/robin-GIT/worktrees/xcsh-4682-postmerge-qualification/packages/coding-agent/src/internal-urls/terraform-property-ranking.ts:279` | Self: 0.0% (0us) | Total: 0.4% (3.3ms) | Samples: 0

**Called by:**
- `propertyMatchesExplicitPaths` (3)

**Calls:**
- `schemaPathMentions` (2)
- `map` (1)

### `searchPropertyIndex`
`/data/robin-GIT/worktrees/xcsh-4682-postmerge-qualification/packages/coding-agent/src/internal-urls/terraform-property-index.ts:193` | Self: 0.0% (0us) | Total: 0.1% (911us) | Samples: 0

**Called by:**
- `(module)` (1)

**Calls:**
- `propertyQueryTerms` (1)

### `(anonymous)`
`/data/robin-GIT/worktrees/xcsh-4682-postmerge-qualification/packages/coding-agent/src/internal-urls/terraform-property-ranking.ts:652` | Self: 0.0% (0us) | Total: 0.1% (1.1ms) | Samples: 0

**Called by:**
- `map` (1)

**Calls:**
- `weight` (1)

### `find`
`[native code]` | Self: 0.0% (0us) | Total: 0.1% (941us) | Samples: 0

**Called by:**
- `selectPropertyDestinationInternal` (1)

**Calls:**
- `(anonymous)` (1)

### `(anonymous)`
`/data/robin-GIT/worktrees/xcsh-4682-postmerge-qualification/packages/coding-agent/src/internal-urls/terraform-property-selection.ts:101` | Self: 0.0% (0us) | Total: 0.4% (3.3ms) | Samples: 0

**Called by:**
- `filter` (3)

**Calls:**
- `propertyMatchesExplicitPaths` (3)

### `selectPropertyDestinationInternal`
`/data/robin-GIT/worktrees/xcsh-4682-postmerge-qualification/packages/coding-agent/src/internal-urls/terraform-property-selection.ts:101` | Self: 0.0% (0us) | Total: 0.4% (3.3ms) | Samples: 0

**Called by:**
- `selectPropertyDestination` (3)

**Calls:**
- `filter` (3)

### `query`
`bun:sqlite:347` | Self: 0.0% (0us) | Total: 0.1% (1.2ms) | Samples: 0

**Called by:**
- `searchPropertyIndex` (1)

**Calls:**
- `[prepareOwned]` (1)

### `searchPropertyIndex`
`/data/robin-GIT/worktrees/xcsh-4682-postmerge-qualification/packages/coding-agent/src/internal-urls/terraform-property-index.ts:317` | Self: 0.0% (0us) | Total: 9.0% (66.3ms) | Samples: 0

**Called by:**
- `(module)` (61)

**Calls:**
- `rankPropertyScope` (59)
- `sort` (1)
- `rankPropertyScope` (1)

### `split`
`[native code]` | Self: 0.0% (0us) | Total: 0.1% (1.1ms) | Samples: 0

**Called by:**
- `propertyRequestedText` (1)

**Calls:**
- `/\bused\s+to\b\|\bat\s+which\b\|\bwhen\s+(?:handling\|processing\|matching\|calling\|invoking\|executing)\b/i` (1)

### `(anonymous)`
`/data/robin-GIT/worktrees/xcsh-4682-postmerge-qualification/packages/coding-agent/src/internal-urls/terraform-property-selection.ts:230` | Self: 0.0% (0us) | Total: 0.1% (1.0ms) | Samples: 0

**Called by:**
- `filter` (1)

**Calls:**
- `identifiersMatch` (1)

### `searchPropertyIndex`
`/data/robin-GIT/worktrees/xcsh-4682-postmerge-qualification/packages/coding-agent/src/internal-urls/terraform-property-index.ts:254` | Self: 0.0% (0us) | Total: 0.1% (1.0ms) | Samples: 0

**Called by:**
- `(module)` (1)

**Calls:**
- `propertyRequestedText` (1)

### `selectPropertyDestinationInternal`
`/data/robin-GIT/worktrees/xcsh-4682-postmerge-qualification/packages/coding-agent/src/internal-urls/terraform-property-selection.ts:258` | Self: 0.0% (0us) | Total: 0.1% (1.1ms) | Samples: 0

**Called by:**
- `selectPropertyDestination` (1)

**Calls:**
- `sort` (1)

### `selectPropertyDestinationInternal`
`/data/robin-GIT/worktrees/xcsh-4682-postmerge-qualification/packages/coding-agent/src/internal-urls/terraform-property-selection.ts:235` | Self: 0.0% (0us) | Total: 3.1% (22.7ms) | Samples: 0

**Called by:**
- `selectPropertyDestination` (21)

**Calls:**
- `filter` (21)

### `(anonymous)`
`/data/robin-GIT/worktrees/xcsh-4682-postmerge-qualification/packages/coding-agent/src/internal-urls/terraform-property-index.ts:306` | Self: 0.0% (0us) | Total: 0.1% (1.2ms) | Samples: 0

**Called by:**
- `map` (1)

**Calls:**
- `parse` (1)

### `(anonymous)`
`/data/robin-GIT/worktrees/xcsh-4682-postmerge-qualification/packages/coding-agent/src/internal-urls/terraform-property-selection.ts:235` | Self: 0.0% (0us) | Total: 2.8% (20.7ms) | Samples: 0

**Called by:**
- `filter` (19)

**Calls:**
- `rawContradicts` (18)
- `rawContradicts` (1)

### `selectPropertyDestinationInternal`
`/data/robin-GIT/worktrees/xcsh-4682-postmerge-qualification/packages/coding-agent/src/internal-urls/terraform-property-selection.ts:230` | Self: 0.0% (0us) | Total: 0.1% (1.0ms) | Samples: 0

**Called by:**
- `selectPropertyDestination` (1)

**Calls:**
- `filter` (1)

### `selectPropertyDestinationInternal`
`/data/robin-GIT/worktrees/xcsh-4682-postmerge-qualification/packages/coding-agent/src/internal-urls/terraform-property-selection.ts:394` | Self: 0.0% (0us) | Total: 0.3% (2.4ms) | Samples: 0

**Called by:**
- `selectPropertyDestination` (2)

**Calls:**
- `filter` (2)

### `searchPropertyIndex`
`/data/robin-GIT/worktrees/xcsh-4682-postmerge-qualification/packages/coding-agent/src/internal-urls/terraform-property-index.ts:211` | Self: 0.0% (0us) | Total: 0.2% (2.0ms) | Samples: 0

**Called by:**
- `(module)` (2)

**Calls:**
- `propertyRequestedType` (2)

### `(anonymous)`
`/data/robin-GIT/worktrees/xcsh-4682-postmerge-qualification/packages/coding-agent/src/internal-urls/terraform-property-ranking.ts:647` | Self: 0.0% (0us) | Total: 0.1% (1.0ms) | Samples: 0

**Called by:**
- `map` (1)

**Calls:**
- `includes` (1)

### `(anonymous)`
`/data/robin-GIT/worktrees/xcsh-4682-postmerge-qualification/packages/coding-agent/src/internal-urls/terraform-property-index.ts:308` | Self: 0.0% (0us) | Total: 0.2% (1.9ms) | Samples: 0

**Called by:**
- `map` (2)

**Calls:**
- `copyDataProperties` (2)

### `every`
`[native code]` | Self: 0.0% (0us) | Total: 0.1% (917us) | Samples: 0

**Called by:**
- `selectPropertyDestinationInternal` (1)

**Calls:**
- `(anonymous)` (1)

### `propertyTerms`
`/data/robin-GIT/worktrees/xcsh-4682-postmerge-qualification/packages/coding-agent/src/internal-urls/terraform-property-selection.ts:67` | Self: 0.0% (0us) | Total: 2.4% (18.1ms) | Samples: 0

**Called by:**
- `rawContradicts` (14)
- `(anonymous)` (3)

**Calls:**
- `propertyTerms` (6)
- `propertyTerms` (4)
- `propertyTerms` (3)
- `propertyTerms` (1)
- `propertyTerms` (1)
- `propertyTerms` (1)
- `propertyTerms` (1)

### `schemaPathMentions`
`/data/robin-GIT/worktrees/xcsh-4682-postmerge-qualification/packages/coding-agent/src/internal-urls/terraform-property-ranking.ts:255` | Self: 0.0% (0us) | Total: 0.3% (2.2ms) | Samples: 0

**Called by:**
- `propertyExplicitSchemaPaths` (2)

**Calls:**
- `performIteration` (2)

### `propertyRequestedText`
`/data/robin-GIT/worktrees/xcsh-4682-postmerge-qualification/packages/coding-agent/src/internal-urls/terraform-property-ranking.ts:479` | Self: 0.0% (0us) | Total: 0.1% (968us) | Samples: 0

**Called by:**
- `propertyRequestsCollection` (1)

**Calls:**
- `/\b(?:specify\|set\|provide\|supply)\b\s+(?!(?:(?:an?\|the)\s+)?(?:xcsh_\|resource\b\|data[ -]source\b\|provider\b))(.+)/i` (1)

### `selectPropertyDestinationInternal`
`/data/robin-GIT/worktrees/xcsh-4682-postmerge-qualification/packages/coding-agent/src/internal-urls/terraform-property-selection.ts:194` | Self: 0.0% (0us) | Total: 0.1% (1.2ms) | Samples: 0

**Called by:**
- `selectPropertyDestination` (1)

**Calls:**
- `interpretTerraformLifecycle` (1)

### `searchPropertyIndex`
`/data/robin-GIT/worktrees/xcsh-4682-postmerge-qualification/packages/coding-agent/src/internal-urls/terraform-property-index.ts:270` | Self: 0.0% (0us) | Total: 0.5% (4.3ms) | Samples: 0

**Called by:**
- `(module)` (4)

**Calls:**
- `all` (4)

### `selectPropertyDestinationInternal`
`/data/robin-GIT/worktrees/xcsh-4682-postmerge-qualification/packages/coding-agent/src/internal-urls/terraform-property-selection.ts:236` | Self: 0.0% (0us) | Total: 62.1% (454.1ms) | Samples: 0

**Called by:**
- `selectPropertyDestination` (420)

**Calls:**
- `filter` (420)

### `propertyMatchesExplicitPaths`
`/data/robin-GIT/worktrees/xcsh-4682-postmerge-qualification/packages/coding-agent/src/internal-urls/terraform-property-ranking.ts:285` | Self: 0.0% (0us) | Total: 0.4% (3.3ms) | Samples: 0

**Called by:**
- `(anonymous)` (3)

**Calls:**
- `propertyExplicitSchemaPaths` (3)

### `selectPropertyDestinationInternal`
`/data/robin-GIT/worktrees/xcsh-4682-postmerge-qualification/packages/coding-agent/src/internal-urls/terraform-property-selection.ts:325` | Self: 0.0% (0us) | Total: 0.1% (923us) | Samples: 0

**Called by:**
- `selectPropertyDestination` (1)

**Calls:**
- `propertyQueryTerms` (1)

### `searchPropertyIndex`
`/data/robin-GIT/worktrees/xcsh-4682-postmerge-qualification/packages/coding-agent/src/internal-urls/terraform-property-index.ts:253` | Self: 0.0% (0us) | Total: 14.8% (108.3ms) | Samples: 0

**Called by:**
- `(module)` (103)

**Calls:**
- `all` (103)

### `(anonymous)`
`/data/robin-GIT/worktrees/xcsh-4682-postmerge-qualification/packages/coding-agent/src/internal-urls/terraform-property-index.ts:307` | Self: 0.0% (0us) | Total: 0.2% (2.0ms) | Samples: 0

**Called by:**
- `map` (2)

**Calls:**
- `parse` (1)
- `copyDataProperties` (1)

### `searchPropertyIndex`
`/data/robin-GIT/worktrees/xcsh-4682-postmerge-qualification/packages/coding-agent/src/internal-urls/terraform-property-index.ts:250` | Self: 0.0% (0us) | Total: 0.1% (1.2ms) | Samples: 0

**Called by:**
- `(module)` (1)

**Calls:**
- `query` (1)

### `searchPropertyIndex`
`/data/robin-GIT/worktrees/xcsh-4682-postmerge-qualification/packages/coding-agent/src/internal-urls/terraform-property-index.ts:294` | Self: 0.0% (0us) | Total: 1.7% (12.8ms) | Samples: 0

**Called by:**
- `(module)` (12)

**Calls:**
- `all` (12)

### `searchPropertyIndex`
`/data/robin-GIT/worktrees/xcsh-4682-postmerge-qualification/packages/coding-agent/src/internal-urls/terraform-property-index.ts:257` | Self: 0.0% (0us) | Total: 0.1% (922us) | Samples: 0

**Called by:**
- `(module)` (1)

**Calls:**
- `flatIntoArrayWithCallback` (1)

### `propertyTerms`
`/data/robin-GIT/worktrees/xcsh-4682-postmerge-qualification/packages/coding-agent/src/internal-urls/terraform-property-ranking.ts:71` | Self: 0.0% (0us) | Total: 0.1% (1.2ms) | Samples: 0

**Called by:**
- `propertyTerms` (1)

**Calls:**
- `filter` (1)

### `propertyTerms`
`/data/robin-GIT/worktrees/xcsh-4682-postmerge-qualification/packages/coding-agent/src/internal-urls/terraform-property-ranking.ts:62` | Self: 0.0% (0us) | Total: 0.1% (1.2ms) | Samples: 0

**Called by:**
- `propertyTerms` (1)

**Calls:**
- `Set` (1)

### `(anonymous)`
`/data/robin-GIT/worktrees/xcsh-4682-postmerge-qualification/packages/coding-agent/src/internal-urls/terraform-property-selection.ts:614` | Self: 0.0% (0us) | Total: 0.1% (941us) | Samples: 0

**Called by:**
- `find` (1)

**Calls:**
- `some` (1)

### `selectPropertyDestinationInternal`
`/data/robin-GIT/worktrees/xcsh-4682-postmerge-qualification/packages/coding-agent/src/internal-urls/terraform-property-selection.ts:358` | Self: 0.0% (0us) | Total: 0.1% (958us) | Samples: 0

**Called by:**
- `selectPropertyDestination` (1)

**Calls:**
- `filter` (1)

### `propertyRequestsCollection`
`/data/robin-GIT/worktrees/xcsh-4682-postmerge-qualification/packages/coding-agent/src/internal-urls/terraform-property-ranking.ts:559` | Self: 0.0% (0us) | Total: 3.5% (25.8ms) | Samples: 0

**Called by:**
- `propertyNamesCollection` (24)

**Calls:**
- `propertyRequestedText` (5)
- `propertyRequestedText` (4)
- `propertyRequestedText` (4)
- `propertyRequestedText` (3)
- `propertyRequestedText` (2)
- `propertyRequestedText` (1)
- `propertyRequestedText` (1)
- `propertyRequestedText` (1)
- `propertyRequestedText` (1)
- `propertyRequestedText` (1)
- `propertyRequestedText` (1)

### `flatIntoArrayWithCallback`
`[native code]` | Self: 0.0% (0us) | Total: 0.1% (922us) | Samples: 0

**Called by:**
- `searchPropertyIndex` (1)

**Calls:**
- `flatIntoArray` (1)

### `selectPropertyDestinationInternal`
`/data/robin-GIT/worktrees/xcsh-4682-postmerge-qualification/packages/coding-agent/src/internal-urls/terraform-property-selection.ts:456` | Self: 0.0% (0us) | Total: 0.1% (1.1ms) | Samples: 0

**Called by:**
- `selectPropertyDestination` (1)

**Calls:**
- `includes` (1)

### `propertyQueryTerms`
`/data/robin-GIT/worktrees/xcsh-4682-postmerge-qualification/packages/coding-agent/src/internal-urls/terraform-property-selection.ts:75` | Self: 0.0% (0us) | Total: 0.1% (923us) | Samples: 0

**Called by:**
- `selectPropertyDestinationInternal` (1)

**Calls:**
- `propertyTerms` (1)

### `identifiersMatch`
`/data/robin-GIT/worktrees/xcsh-4682-postmerge-qualification/packages/coding-agent/src/internal-urls/terraform-property-selection.ts:142` | Self: 0.0% (0us) | Total: 0.1% (1.0ms) | Samples: 0

**Called by:**
- `(anonymous)` (1)

**Calls:**
- `identifiersFor` (1)

### `(anonymous)`
`/data/robin-GIT/worktrees/xcsh-4682-postmerge-qualification/packages/coding-agent/src/internal-urls/terraform-property-ranking.ts:738` | Self: 0.0% (0us) | Total: 0.1% (1.0ms) | Samples: 0

**Called by:**
- `map` (1)

**Calls:**
- `toFixed` (1)

### `identifiersFor`
`/data/robin-GIT/worktrees/xcsh-4682-postmerge-qualification/packages/coding-agent/src/internal-urls/terraform-property-selection.ts:140` | Self: 0.0% (0us) | Total: 0.1% (1.0ms) | Samples: 0

**Called by:**
- `identifiersMatch` (1)

**Calls:**
- `filter` (1)

### `rawContradicts`
`/data/robin-GIT/worktrees/xcsh-4682-postmerge-qualification/packages/coding-agent/src/internal-urls/terraform-property-selection.ts:41` | Self: 0.0% (0us) | Total: 2.6% (19.5ms) | Samples: 0

**Called by:**
- `(anonymous)` (18)

**Calls:**
- `propertyTerms` (14)
- `Set` (2)
- `propertyTerms` (1)
- `propertyTerms` (1)

### `(anonymous)`
`/data/robin-GIT/worktrees/xcsh-4682-postmerge-qualification/packages/coding-agent/src/internal-urls/terraform-property-selection.ts:240` | Self: 0.0% (0us) | Total: 0.5% (4.2ms) | Samples: 0

**Called by:**
- `filter` (4)

**Calls:**
- `propertyNamesCollection` (4)

### `selectPropertyDestinationInternal`
`/data/robin-GIT/worktrees/xcsh-4682-postmerge-qualification/packages/coding-agent/src/internal-urls/terraform-property-selection.ts:530` | Self: 0.0% (0us) | Total: 0.1% (917us) | Samples: 0

**Called by:**
- `selectPropertyDestination` (1)

**Calls:**
- `every` (1)

### `selectPropertyDestinationInternal`
`/data/robin-GIT/worktrees/xcsh-4682-postmerge-qualification/packages/coding-agent/src/internal-urls/terraform-property-selection.ts:549` | Self: 0.0% (0us) | Total: 0.1% (941us) | Samples: 0

**Called by:**
- `selectPropertyDestination` (1)

**Calls:**
- `find` (1)

### `searchPropertyIndex`
`/data/robin-GIT/worktrees/xcsh-4682-postmerge-qualification/packages/coding-agent/src/internal-urls/terraform-property-index.ts:302` | Self: 0.0% (0us) | Total: 1.4% (10.8ms) | Samples: 0

**Called by:**
- `(module)` (10)

**Calls:**
- `map` (10)

### `(anonymous)`
`/data/robin-GIT/worktrees/xcsh-4682-postmerge-qualification/packages/coding-agent/src/internal-urls/terraform-property-selection.ts:242` | Self: 0.0% (0us) | Total: 0.9% (6.7ms) | Samples: 0

**Called by:**
- `filter` (6)

**Calls:**
- `propertyRequestedText` (1)
- `propertyRequestedText` (1)
- `propertyRequestedText` (1)
- `propertyRequestedText` (1)
- `propertyRequestedText` (1)
- `propertyRequestedText` (1)

### `rankPropertyScope`
`/data/robin-GIT/worktrees/xcsh-4682-postmerge-qualification/packages/coding-agent/src/internal-urls/terraform-property-ranking.ts:624` | Self: 0.0% (0us) | Total: 8.7% (63.9ms) | Samples: 0

**Called by:**
- `searchPropertyIndex` (59)

**Calls:**
- `map` (59)

### `(anonymous)`
`/data/robin-GIT/worktrees/xcsh-4682-postmerge-qualification/packages/coding-agent/src/internal-urls/terraform-property-ranking.ts:719` | Self: 0.0% (0us) | Total: 0.1% (1.1ms) | Samples: 0

**Called by:**
- `map` (1)

**Calls:**
- `copyDataProperties` (1)

### `(anonymous)`
`/data/robin-GIT/worktrees/xcsh-4682-postmerge-qualification/packages/coding-agent/src/internal-urls/terraform-property-index.ts:314` | Self: 0.0% (0us) | Total: 0.1% (1.1ms) | Samples: 0

**Called by:**
- `map` (1)

**Calls:**
- `parse` (1)

## Files

| Self% | Self | File |
|------:|-----:|------|
| 56.8% | 415.9ms | `/data/robin-GIT/worktrees/xcsh-4682-postmerge-qualification/packages/coding-agent/src/internal-urls/terraform-property-selection.ts` |
| 30.7% | 224.6ms | `[native code]` |
| 11.5% | 84.0ms | `/data/robin-GIT/worktrees/xcsh-4682-postmerge-qualification/packages/coding-agent/src/internal-urls/terraform-property-ranking.ts` |
| 0.6% | 5.0ms | `/data/robin-GIT/worktrees/xcsh-4682-postmerge-qualification/packages/coding-agent/src/internal-urls/terraform-property-index.ts` |
| 0.1% | 1.2ms | `/data/robin-GIT/worktrees/xcsh-4682-postmerge-qualification/packages/coding-agent/src/internal-urls/terraform-lifecycle.ts` |
