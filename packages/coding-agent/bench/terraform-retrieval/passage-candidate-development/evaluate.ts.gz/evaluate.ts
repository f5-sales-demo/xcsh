import {Database} from "bun:sqlite";
import {readFileSync,writeFileSync} from "node:fs";
import {boundedSectionCandidates} from "/data/robin-GIT/worktrees/xcsh-4682-postmerge-qualification/packages/coding-agent/bench/terraform-retrieval/bounded-rerank";
const db=new Database("/tmp/terraform-v1240-canonical-evidence-cache/727e3a7a02316ddf0b65beee926e014221cce93e6618e32e1d64a16238c42a3e.sqlite",{readonly:true});
const cases=JSON.parse(readFileSync("/tmp/terraform-current-hybrid-development/suite.json","utf8"));
const results=[];
for(const c of cases){if(c.kind!=="answerable")continue;const start=performance.now();const rows=boundedSectionCandidates(db,c.prompt);const destinations=rows.map(r=>"xcsh://terraform-documentation/"+r.path+"#"+r.anchor);results.push({id:c.id,top1:c.expected.includes(destinations[0]),top5:destinations.some(d=>c.expected.includes(d)),destinations,ms:performance.now()-start});}
const report={development_only:true,qualification_passed:false,production_imported:false,answerable:results.length,top1:results.filter(r=>r.top1).length,top5:results.filter(r=>r.top5).length,results};
writeFileSync("/tmp/terraform-passage-development.json",JSON.stringify(report,null,2));console.log(JSON.stringify({...report,results:undefined}));
