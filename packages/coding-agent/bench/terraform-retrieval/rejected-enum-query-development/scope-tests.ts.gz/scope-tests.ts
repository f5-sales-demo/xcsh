import { expect, test } from "bun:test";
import { enumScopeQuery } from "../../src/internal-urls/terraform-enum-evidence";

test("supplied literal occurrence preserves separately named branch", () => {
	const result = enumScopeQuery("Which field under value_scope accepts value_scope", "value_scope");
	expect(result.query).toBe("Which field under value_scope accepts ");
	expect(enumScopeQuery("Which field accepts `ROUND_ROBIN`?", "ROUND_ROBIN").query).toBe("Which field accepts ?");
	expect(enumScopeQuery("Which field under ROUND_ROBIN accepts GRE", "GRE").query).toContain("under ROUND_ROBIN");
});
test("dotted exclusions retain exact contiguous paths rather than positive identifiers", () => {
	const result = enumScopeQuery("Which field outside value_scope.protocol accepts GRE", "GRE");
	expect(result.excludedPaths).toEqual(["value_scope.protocol"]);
	expect(result.query).not.toContain("value_scope");
});
test("literal metacharacters remain exact and unrelated phrasing stays intact", () => {
	expect(enumScopeQuery("Which field accepts A+B?", "A+B").query).toBe("Which field accepts ?");
	expect(enumScopeQuery("Which field accepts AXB?", "A+B").query).toBe("Which field accepts AXB?");
});

test("dotted exclusions preserve sentence punctuation and negation", () => {
	expect(enumScopeQuery("Which field excluding value_scope.protocol accepts GRE", "GRE").excludedPaths).toEqual([
		"value_scope.protocol",
	]);
	expect(enumScopeQuery("Which field outside value_scope.protocol.", "GRE").excludedPaths).toEqual([
		"value_scope.protocol",
	]);
	expect(enumScopeQuery("Which field not outside value_scope.protocol accepts GRE", "GRE").excludedPaths).toEqual([]);
});
