import {Database} from "bun:sqlite";
import {writeFileSync} from "node:fs";
const db=new Database("/tmp/terraform-v1240-canonical-evidence-cache/727e3a7a02316ddf0b65beee926e014221cce93e6618e32e1d64a16238c42a3e.sqlite",{readonly:true});
const groups=db.query("SELECT provider_name,schema_path,leaf FROM property_terms ORDER BY provider_name,schema_path").all();
const unique=new Map(groups.map(r=>[r.provider_name+":"+r.schema_path.split(".").at(-1),{name:r.provider_name,terminal:r.schema_path.split(".").at(-1),leaf:r.leaf}]));
const old=db.query("SELECT provider_type,schema_path,path,anchor FROM property_terms WHERE provider_name=? AND (schema_path=? OR substr(schema_path,-length(?))=?) ORDER BY provider_type,schema_path");
const next=db.query("SELECT provider_type,schema_path,path,anchor FROM property_terms WHERE provider_name=? AND leaf=? AND (schema_path=? OR substr(schema_path,-length(?))=?) ORDER BY provider_type,schema_path");
const oldMs=[],newMs=[];let count=0;
for(const g of unique.values()){const suffix="."+g.terminal;let start=performance.now();const a=old.all(g.name,g.terminal,suffix,suffix);oldMs.push(performance.now()-start);start=performance.now();const b=next.all(g.name,g.leaf,g.terminal,suffix,suffix);newMs.push(performance.now()-start);if(JSON.stringify(a)!==JSON.stringify(b))throw new Error("Alternative identity changed");count++;}
const p95=a=>a.sort((a,b)=>a-b)[Math.ceil(a.length*.95)-1];
const report={development_only:true,qualification_passed:false,provider_version:"v12.4.0",groups_verified:count,all_alternative_sets_identical:true,old_lookup_p95_ms:p95(oldMs),indexed_lookup_p95_ms:p95(newMs),plan:db.query("EXPLAIN QUERY PLAN SELECT * FROM property_terms WHERE provider_name=? AND leaf=? AND (schema_path=? OR substr(schema_path,-length(?))=?)").all("http_loadbalancer","[\"port\"]","port",".port",".port")};writeFileSync("/tmp/terraform-leaf-alternatives-measure.json",JSON.stringify(report,null,2));console.log(JSON.stringify(report));db.close();