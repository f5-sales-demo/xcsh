export interface IpStackIntent {mode?:"single"|"dual";family?:"ipv4"|"ipv6";uncertain:boolean;}
export function requestedIpStack(query:string):IpStackIntent{
 const mentions=[...query.matchAll(/\b(?:ipv[46][ -]only|single[ -]stack|dual[ -]stack)\b/gi)];
 if(!mentions.length)return {uncertain:false};
 if(query.split(/[!?;]|\.(?=\s|$)/).filter(c=>c.trim()).length>1)return {uncertain:true};
 const modes=new Set<"single"|"dual">(),families=new Set<"ipv4"|"ipv6">();
 for(const mention of mentions){
  const start=mention.index!,end=start+mention[0].length;
  const before=query.slice(0,start).split(/[.!?;]|\bbut\b/i).at(-1)??"";
  const after=query.slice(end).split(/[.!?;]/)[0]??"";
  if(/["'`‘’“”]/.test(query)||/\b(?:not|no|never|without|either|or|maybe|possibly|example|such as|instead of|rather than)\b/i.test(before+" "+after))return {uncertain:true};
  const phrase=mention[0].toLowerCase();modes.add(phrase.startsWith("dual")?"dual":"single");
  if(phrase.startsWith("ipv4"))families.add("ipv4");if(phrase.startsWith("ipv6"))families.add("ipv6");
 }
 if(modes.size!==1||families.size>1)return {uncertain:true};
 return {mode:[...modes][0],family:families.size===1?[...families][0]:undefined,uncertain:false};
}
export function matchesIpStack(path:string,intent:IpStackIntent):boolean{
 if(intent.uncertain||!intent.mode)return true;
 const segments=path.split(".");
 if(!segments.some(s=>s==="ipv4"||s==="ipv6"||s==="dual_stack"))return true;
 if(intent.mode==="single"&&segments.includes("dual_stack"))return false;
 if(intent.mode==="dual"&&!segments.includes("dual_stack"))return false;
 if(intent.family&&segments.includes(intent.family==="ipv4"?"ipv6":"ipv4")&&!segments.includes(intent.family))return false;
 return true;
}
