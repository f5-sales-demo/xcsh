import {expect,test} from "bun:test";
import {requestedIpStack,matchesIpStack} from "../../src/internal-urls/terraform-ip-stack";
import {selectPropertyDestination} from "../../src/internal-urls/terraform-property-selection";
const row=(schema_path:string,score:number)=>({provider_type:"resources",provider_name:"fixture",schema_path,path:schema_path,anchor:"schema-"+schema_path,description:"IPv6 address.",score,coverage:1});
test("explicit family-only scope distinguishes dual from single and omitted scope stays undecided",()=>{
 const rows=[row("outside.dual_stack.ipv6.addr",50),row("outside.ipv6.addr",49)];
 expect(selectPropertyDestination("outside IPv6-only address",rows).destinations[0]?.schema_path).toBe("outside.ipv6.addr");
 expect(selectPropertyDestination("outside IPv6-only address",rows).kind).toBe("leaf");
 expect(selectPropertyDestination("outside IPv6 address",rows).kind).toBe("choices");
 expect(matchesIpStack("outside.dual_stack.ipv6.addr",requestedIpStack("outside IPv6-only address"))).toBe(false);
});
test("stack intent cannot come from uncertainty quotation comparisons or examples",()=>{
 for(const q of ['not IPv6-only address','"IPv6-only" address','either IPv6-only or dual-stack','possibly IPv6-only','example IPv6-only','IPv6-only or IPv4-only','dual-stack and single-stack'])expect(requestedIpStack(q).uncertain).toBe(true);
});
test("stack restriction never rejects unrelated paths and preserves leaf score",()=>{
 expect(matchesIpStack("timeouts.create",requestedIpStack("IPv6-only address"))).toBe(true);
 const r=row("outside.ipv6.addr",3);expect(selectPropertyDestination("outside IPv6-only address",[r]).destinations[0]?.score).toBe(3);
});

test("stack labels outside a property request cannot decide its branch",()=>{
 const rows=[row("routes.dual_stack.ipv6.addr",50),row("routes.ipv6.addr",49)];
 expect(selectPropertyDestination("The host runs IPv6-only. Locate the IPv6 address field",rows).kind).toBe("choices");
 expect(selectPropertyDestination("Locate the IPv6 address field. An unrelated interface is IPv6-only",rows).kind).toBe("choices");
});
