import {expect,test} from "bun:test";
import {preparePropertyScope,rankPropertyScope} from "../../src/internal-urls/terraform-property-ranking";
import {selectPropertyDestination} from "../../src/internal-urls/terraform-property-selection";
const row=(schema_path:string,description:string,extra:any={})=>({provider_type:"resources",provider_name:"fixture",schema_path,path:schema_path,anchor:"schema-"+schema_path.replaceAll(".","--"),description,...extra});
const route=(q:string,rows:any[])=>selectPropertyDestination(q,rankPropertyScope(q,preparePropertyScope(rows)),[],{identityResolved:true});
test("qualified target support outranks root and ancestor vocabulary",()=>{
 const q="Which field sets duration without traffic under connection?";
 const rows=[row("duration","Duration."),row("connection.idle_timeout","Duration without traffic."),row("connection.duration.value","Opaque value.")];
 expect(route(q,rows).kind).toBe("leaf");expect(route(q,rows).destinations[0]?.schema_path).toBe("connection.idle_timeout");
 expect(route(q,[rows[2]]).kind).toBe("choices");
});
test("local documented prose supports a terse qualified field",()=>{
 const rows=[row("connection.wait_limit","Limit.",{documentation_terms:["duration","without","traffic"]}),row("connection.duration.value","Opaque value.")];
 expect(route("Which field sets duration without traffic under connection?",rows).destinations[0]?.schema_path).toBe("connection.wait_limit");
 expect(route("Which field sets duration without traffic under connection?",rows).kind).toBe("leaf");
});
test("qualified ancestry stays separate from incidental description text",()=>{
 const rows=[row("connection.idle_timeout","Duration without traffic."),row("session.idle_timeout","Duration without traffic; connection setting.")];
 expect(route("Which field sets duration without traffic within session?",rows).destinations[0]?.schema_path).toBe("session.idle_timeout");
 expect(route("Which field sets duration without traffic under connection?",rows).destinations[0]?.schema_path).toBe("connection.idle_timeout");
});
test("missing and uncertain placement preserves repeated leaf choices",()=>{
 const rows=[row("connection.idle_timeout","Duration without traffic."),row("session.idle_timeout","Duration without traffic.")];
 for(const q of ["Which field sets duration without traffic?","Which field sets duration without traffic under connection or session?","Which field sets duration without traffic not under connection?"])expect(route(q,rows).kind).toBe("choices");
});
test("qualified literal field requires a terminal identifier",()=>{
 const rows=[row("connection.retry_limit","Retry limit."),row("connection.retry_limit.value","Retry limit value."),row("connection.retry_limits","Retry limits.")];
 const result=route("Locate the field retry_limit under connection",rows);
 expect(result.kind).toBe("leaf");expect(result.destinations[0]?.schema_path).toBe("connection.retry_limit");
 expect(route("Locate the field invented_limit under connection",rows).kind).toBe("none");
});
test("qualified aliases alone cannot establish leaf support",()=>{
 expect(route("Which field sets duration without traffic under connection?",[row("connection.opaque","Opaque value.",{aliases:["duration without traffic"]})]).kind).toBe("choices");
});
test("eligible qualified peers beyond five retain ambiguity",()=>{
 const rows=Array.from({length:6},(_,i)=>row("connection.branch"+i+".idle_timeout","Duration without traffic."));
 expect(route("Which field sets duration without traffic under connection?",rows).kind).toBe("choices");
});
test("qualified selection preserves identity uncertainty",()=>{
 const rows=[row("connection.idle_timeout","Duration without traffic."),row("connection.idle_timeout","Duration without traffic.",{provider_type:"data-sources",path:"data"})];
 expect(selectPropertyDestination("Which field sets duration without traffic under connection?",rankPropertyScope("Which field sets duration without traffic under connection?",preparePropertyScope(rows)),[],{identityResolved:false}).kind).toBe("choices");
});
