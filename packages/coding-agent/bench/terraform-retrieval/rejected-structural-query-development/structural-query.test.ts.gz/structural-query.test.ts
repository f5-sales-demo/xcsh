import {expect,test} from "bun:test";
import {resolveStructuralQuery} from "./structural-query";
const row=(schema_path:string)=>({provider_type:"resources",provider_name:"fixture",schema_path,path:schema_path,anchor:"schema-"+schema_path});
test("literal branch evidence resolves each independent fork and keeps omitted family ambiguous",()=>{const rows=[row("primary.ipv4.address"),row("primary.ipv6.address"),row("secondary.ipv4.address"),row("secondary.ipv6.address")];expect(resolveStructuralQuery("primary address",rows).kind).toBe("choices");expect(resolveStructuralQuery("primary IPv6 address",rows).destinations).toEqual([rows[1]!]);expect(resolveStructuralQuery("primary IPv4 and IPv6 address",rows).kind).toBe("choices");});
test("quoted negative uncertain and example mentions cannot identify branches",()=>{const rows=[row("primary.address"),row("secondary.address")];for(const q of ["not primary address","maybe primary address","example primary address","either primary or secondary address","primary or secondary address","primary address or secondary address","a setting named primary address","primary is not the desired branch","\"primary address\""]){expect(resolveStructuralQuery(q,rows).kind).toBe("choices");}});
test("unordered repeated segment words cannot assign schema order",()=>{expect(resolveStructuralQuery("source destination name",[row("source.destination.name"),row("destination.source.name")]).kind).toBe("choices");});
test("shared terminal words cannot select root over a referenced leaf",()=>{const rows=[row("namespace"),row("attachments.target.namespace")];expect(resolveStructuralQuery("namespace",rows).kind).toBe("choices");expect(resolveStructuralQuery("attachments target namespace",rows).destinations).toEqual([rows[1]!]);});

test("a repeated segment cannot bind an arbitrary nesting occurrence",()=>{const rows=[row("storage.volume_defaults.encryption"),row("storage.storage.volume_defaults.encryption")];expect(resolveStructuralQuery("storage volume defaults encryption",rows).kind).toBe("choices");});

test("ancestor label repeated elsewhere cannot uniquely bind a fork",()=>{const rows=[row("storage.volume_defaults.encryption"),row("volume_defaults.storage.encryption")];expect(resolveStructuralQuery("storage volume defaults encryption",rows).kind).toBe("choices");});

test("one storage mention cannot imply the second repeated storage level",()=>{const rows=[row("storage.volume_defaults.encryption"),row("storage.storage.volume_defaults.encryption")];expect(resolveStructuralQuery("storage encryption",rows).kind).toBe("choices");});
