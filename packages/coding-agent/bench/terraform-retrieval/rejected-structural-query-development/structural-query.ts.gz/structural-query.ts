// Development-only binding of literal query spans to ordered schema forks.
import {filterStructuralDestinations,type BoundStructuralEvidence,type StructuralDestination} from "./structural-peers";
export function bindStructuralQuery(query:string,rows:readonly StructuralDestination[]){
 const evidence:BoundStructuralEvidence[]=[];
 const normalized=query.toLowerCase().replace(/[_-]/g," ");
 const paths=rows.map(r=>r.schema_path.split("."));
 const forks=new Map<string,Set<string|null>>();
 for(const parts of paths)for(let i=0;i<=parts.length;i++){const parent=JSON.stringify(parts.slice(0,i));const next=parts[i]??null;const choices=forks.get(parent)??new Set();choices.add(next);forks.set(parent,choices);}
 for(const [key,choices] of forks){if(choices.size<2)continue;const parent=JSON.parse(key) as string[];const activePaths=filterStructuralDestinations(rows,evidence).destinations.map(r=>r.schema_path.split("."));
 for(const segment of choices){if(segment===null)continue;
 // A terminal word shared by the requested leaves cannot identify its root branch.
 if(paths.some(parts=>parts.at(-1)===segment))continue;
 const locations=new Set(activePaths.flatMap(parts=>parts.flatMap((part,index)=>part===segment?[JSON.stringify(parts.slice(0,index))]:[])));if(locations.size!==1)continue;
 const phrase=segment.replaceAll("_"," ");const escaped=phrase.replace(/[.*+?^${}()|[\]\\]/g,"\\$&");
 const pattern=new RegExp("\\b"+escaped+"\\b","g");
 for(const match of normalized.matchAll(pattern)){const start=match.index!,end=start+match[0].length;const clauseStart=Math.max(normalized.lastIndexOf(".",start-1),normalized.lastIndexOf(";",start-1),normalized.lastIndexOf("!",start-1),normalized.lastIndexOf("?",start-1))+1;const before=normalized.slice(clauseStart,start);const endOffset=normalized.slice(end).search(/[.;!?]/);const clause=normalized.slice(clauseStart,endOffset<0?normalized.length:end+endOffset);if(/[\"`]/.test(clause)||/\b(?:example|such as|maybe|possibly|either|or|not|no|never|without|excluding|rather than|instead of|named|called)\b/.test(clause))continue;
 if(/[\"`]/.test(before)||/\b(?:example|such as|maybe|possibly|either|or|not|no|never|without|excluding|rather than|instead of)\b/.test(before))continue;
 evidence.push({parent,segment,polarity:"positive",querySpan:[start,end],source:"literal schema segment"});}
 }
 }
 return evidence;
}
export function resolveStructuralQuery(query:string,rows:readonly StructuralDestination[]){return filterStructuralDestinations(rows,bindStructuralQuery(query,rows));}
