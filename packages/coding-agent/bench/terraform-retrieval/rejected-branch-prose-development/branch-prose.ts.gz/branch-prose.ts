import type {Database} from "bun:sqlite";
import {propertyTerms,propertyQueryTerms} from "../../src/internal-urls/terraform-property-ranking";
import type {RankedProperty} from "../../src/internal-urls/terraform-property-selection";
export interface BranchProse {schema_path:string;description:string;}
export function indexedBranchDescriptions(db:Database,providerType:string,providerName:string,paths:readonly string[]){
 const ancestors=new Set<string>();for(const path of paths){const parts=path.split(".");for(let i=1;i<parts.length;i++)ancestors.add(parts.slice(0,i).join("."));}
 if(!ancestors.size)return [];
 const keys=[...ancestors].sort();return db.query(`SELECT schema_path,description FROM terraform_destinations WHERE provider_type=? AND provider_name=? AND anchor="section" AND schema_path IN (${keys.map(()=>"?").join(",")}) ORDER BY schema_path`).all(providerType,providerName,...keys) as BranchProse[];
}
export function branchProseFilter(query:string,rows:readonly RankedProperty[],descriptions:readonly BranchProse[]){
 // Development policy: descriptive terms narrow branches only, never establish leaf capability.
 if(/[\"`‘’“”]|\b(?:not|no|never|without|either|or|example|such as|instead of|rather than)\b/i.test(query))return [...rows];
 const q=new Set(propertyQueryTerms(query));const evidence=new Map<string,Set<string>>();
 for(const r of descriptions){const parent=r.schema_path.split(".").slice(0,-1).join(".");const own=new Set(r.description.split(/[.!?;]/).filter(c=>!/\b(?:not|no|never|without|example|such as|for instance)\b/i.test(c)).flatMap(c=>propertyTerms(c))); const peers=descriptions.filter(p=>p.schema_path!==r.schema_path&&p.schema_path.split(".").slice(0,-1).join(".")===parent);if(!peers.length)continue;
 const unique=[...own].filter(t=>!peers.some(p=>propertyTerms(p.description).includes(t)));const matched=unique.filter(t=>q.has(t));if(matched.length){const choices=evidence.get(parent)??new Set<string>();choices.add(r.schema_path);evidence.set(parent,choices);}}
 return rows.filter(row=>[...evidence].every(([parent,choices])=>choices.size!==1||!row.schema_path.startsWith(parent?parent+".":"")||[...choices].some(c=>row.schema_path===c||row.schema_path.startsWith(c+"."))));
}
