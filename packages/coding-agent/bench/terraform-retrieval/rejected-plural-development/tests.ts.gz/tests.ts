import { expect, test } from "bun:test";
import { propertyQueryTerms, propertyTerms } from "../../src/internal-urls/terraform-property-ranking";

test("plural query vocabulary reaches existing singular canonical terms", () => {
	expect(propertyQueryTerms("hostnames")).toEqual(propertyQueryTerms("hostname"));
	expect(propertyQueryTerms("addresses")).toEqual(propertyQueryTerms("address"));
});
test("query normalization preserves schema tokenizer and exact literals", () => {
	expect(propertyTerms("hostnames")).toEqual(["hostname"]);
	expect(propertyTerms("addresses")).toEqual(["addresse"]);
	expect(propertyQueryTerms("`hostnames`")).toEqual(["hostname"]);
	expect(propertyQueryTerms("schema.addresses")).toContain("addresse");
});
