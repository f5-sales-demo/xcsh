import {expect,test} from "bun:test";
import {enumChoiceRequest,documentedEnumValues,enumSupportsChoice} from "../../src/internal-urls/terraform-enum-choice";
const request=enumChoiceRequest("In a Terraform fixture resource, where do I select alpha versus beta encapsulation?")!;
test("choice grammar preserves alternatives and rejects incidental or incomplete requests",()=>{
 expect(request).toEqual({alternatives:["alpha","beta"],concept:"encapsulation"});
 for(const q of ["Choose alpha versus beta","Where do I choose purple versus ultraviolet field?","Locate timeout; where do I select alpha versus beta encapsulation?","Do not choose alpha versus beta encapsulation?","Where do I select alpha versus beta encapsulation with encryption?","Locate port (for example where do I select alpha versus beta encapsulation?)"])expect(enumChoiceRequest(q)).toBeUndefined();
});
test("only direct provider OneOf evidence supplies enum values",()=>{
 const md='Provider validators and defaults (from schema source):\n\n```go\nValidators: []validator.String{ stringvalidator.OneOf("ALPHA_PSK", "BETA"), }\n```\n\nReceipt-pinned upstream constraints:\n{"enum":["OTHER"]}';
 expect(documentedEnumValues(md)).toEqual(["ALPHA_PSK","BETA"]);
 expect(enumSupportsChoice(documentedEnumValues(md),request)).toBe(true);
 expect(enumSupportsChoice(["ALPHA_PSK","ALPHA_OTHER","BETA"],request)).toBe(false);
 expect(documentedEnumValues('Description OneOf("ALPHA","BETA")')).toEqual([]);
 expect(documentedEnumValues('Receipt-pinned upstream constraints:\n{"enum":["ALPHA","BETA"]}')).toEqual([]);
 expect(enumSupportsChoice(["BETA"],request)).toBe(false);
});

test("enum evidence rejects comments strings and invalid argument syntax",()=>{
 const wrap=(code:string)=>"Provider validators and defaults (from schema source):\n\n```go\n"+code+"\n```";
 for(const code of ['// stringvalidator.OneOf("ALPHA","BETA")','Description: `stringvalidator.OneOf("ALPHA","BETA")`','Validators: []validator.String{stringvalidator.OneOf("ALPHA" "BETA")},'])expect(documentedEnumValues(wrap(code))).toEqual([]);
 expect(documentedEnumValues(wrap('Validators: []validator.String{stringvalidator.OneOf("ALPHA","BETA")},'))).toEqual(["ALPHA","BETA"]);
});

test("enum choices reject malformed blocks and multiple requests; exact compound values match",()=>{
 const wrap=(code:string)=>"Provider validators and defaults (from schema source):\n\n```go\n"+code+"\n```";
 for(const code of ['Validators: []validator.String{ stringvalidator.OneOf("ALPHA","BETA")','Validators: []validator.String{ garbage stringvalidator.OneOf("ALPHA","BETA") }','Validators: []validator.String{}\nstringvalidator.OneOf("ALPHA","BETA")'])expect(documentedEnumValues(wrap(code))).toEqual([]);
 for(const q of ["Find timeout and where do I select alpha versus beta encapsulation?","Where do I select alpha versus beta encapsulation, where do I select gamma versus delta routing?"])expect(enumChoiceRequest(q)).toBeUndefined();
 expect(enumSupportsChoice(["ALPHA_PSK","BETA"],{alternatives:["alpha_psk","beta"],concept:"encapsulation"})).toBe(true);
});
