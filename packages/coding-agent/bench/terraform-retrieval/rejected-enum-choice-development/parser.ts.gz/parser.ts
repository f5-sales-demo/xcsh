
export interface EnumChoiceRequest { alternatives:[string,string]; concept:string }
export function enumChoiceRequest(text:string):EnumChoiceRequest|undefined {
 if(/[`"'‘’“”()]|\b(?:not|no|never|without|or|either|and|then|example|explain|avoid|compare)\b/i.test(text))return undefined;
 if(/[;\n]|[.!?].*\S/.test(text))return undefined;
 const matches=[...text.matchAll(/\b(?:find|locate|where|which|what)\b/gi)];
 if(matches.length!==1||matches[0]![0].toLowerCase()!=="where")return undefined;
 const m=/\bwhere\s+do\s+i\s+(?:select|choose)\s+([a-z][a-z0-9_-]*)\s+(?:versus|vs)\s+([a-z][a-z0-9_-]*)\s+([a-z][a-z0-9_-]*)\s*[.!?]?$/i.exec(text);
 if(!m||text.slice(m.index).includes(",")||["field","property","block","value"].includes(m[3]!.toLowerCase()))return undefined;
 return {alternatives:[m[1]!,m[2]!],concept:m[3]!};
}
export function documentedEnumValues(markdown:string):string[] {
 const marker="Provider validators and defaults (from schema source):";
 if(markdown.split(marker).length!==2)return [];
 const prose=markdown.split(marker)[1]!.split("Receipt-pinned upstream constraints:")[0]!.trim();
 const block=/^```go\s*\n\s*Validators:\s*\[\]validator\.String\s*\{\s*stringvalidator\.OneOf\(\s*("[^"\\]*"(?:\s*,\s*"[^"\\]*")*\s*,?)\s*\)\s*,?\s*\}\s*,?\s*\n```$/.exec(prose);
 if(!block)return [];
 return [...block[1]!.matchAll(/"([^"]+)"/g)].map(m=>m[1]!);
}
export function enumSupportsChoice(values:readonly string[],request:EnumChoiceRequest):boolean {
 const matches=request.alternatives.map(option=>{
  const exact=values.flatMap((value,i)=>value.toLowerCase()===option.toLowerCase()?[i]:[]);
  if(exact.length)return exact;
  return values.flatMap((value,i)=>value.toLowerCase().split(/[_-]/).includes(option.toLowerCase())?[i]:[]);
 });
 return matches.every(m=>m.length===1)&&matches[0]![0]!==matches[1]![0];
}
