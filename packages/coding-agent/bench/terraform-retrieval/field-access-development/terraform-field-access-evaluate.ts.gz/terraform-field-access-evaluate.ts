import {requestedFieldAccess,matchesFieldAccess} from "/data/robin-GIT/worktrees/xcsh-4682-postmerge-qualification/packages/coding-agent/bench/terraform-retrieval/field-access";
import {Database} from "bun:sqlite";
import {readFileSync,writeFileSync} from "node:fs";
import {terraformProviderMention,terraformQueryIdentity} from "/data/robin-GIT/worktrees/xcsh-4682-postmerge-qualification/packages/coding-agent/src/internal-urls/terraform-documentation";
import {searchPropertyIndex} from "/data/robin-GIT/worktrees/xcsh-4682-postmerge-qualification/packages/coding-agent/src/internal-urls/terraform-property-index";
import {propertyQueryTerms} from "/data/robin-GIT/worktrees/xcsh-4682-postmerge-qualification/packages/coding-agent/src/internal-urls/terraform-property-ranking";
const db=new Database("/tmp/terraform-v1240-canonical-evidence-cache/727e3a7a02316ddf0b65beee926e014221cce93e6618e32e1d64a16238c42a3e.sqlite",{readonly:true});
const results=[];
for(const file of ["/tmp/terraform-current-hybrid-development/suite.json","/tmp/terraform-v1240-qualification-v7-corrected-frozen/heldout.json"]){
 const cases=JSON.parse(readFileSync(file,"utf8"));let total=0,top1=0,top5=0;const rows=[];
 for(const c of cases){if(c.kind!=="answerable")continue;const start=performance.now();
 const role=terraformQueryIdentity(c.prompt).providerType;
 const names=(db.query("SELECT DISTINCT provider_name FROM property_scopes WHERE (? IS NULL OR provider_type=?) ORDER BY provider_name").all(role??null,role??null) as any[]).map(x=>x.provider_name);
 const provider=terraformProviderMention(c.prompt,names);const terms=propertyQueryTerms(c.prompt);
 const candidates=searchPropertyIndex(db,c.prompt,{providerType:role,providerName:provider},2000).filter(r=>matchesFieldAccess(r,requestedFieldAccess(c.prompt))).slice(0,5);
 const dest=candidates.map(x=>"xcsh://terraform-documentation/"+x.path+"#"+x.anchor);
 total++;if(c.expected.includes(dest[0]))top1++;if(dest.some(d=>c.expected.includes(d)))top5++;
 rows.push({id:c.id,role,provider,destinations:dest,ms:performance.now()-start});
 }results.push({file,total,top1,top5,results:rows});
}
writeFileSync("/tmp/terraform-field-access-development.json",JSON.stringify({qualification_passed:false,development_only:true,post_analysis_regression:true,results},null,2));console.log(results.map(({results,...summary})=>summary));
